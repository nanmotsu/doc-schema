# 仕様YAML → Excel出力基盤 実装指示書

## 1. 目的

Pythonで、既存システムから作成された「機能単位の仕様YAML」を読み込み、既存Excelテンプレートへ出力できる汎用基盤を作成する。

処理方向は以下のみとする。

```text
機能仕様YAML
    ↓
Python
    ↓
Excel
```

ExcelからYAMLへの逆変換は実装しない。

---

# 2. 基本方針

以下を分離する。

```text
機能仕様YAML
    = 何のデータ・仕様が存在するか

Layout.py
    = YAMLのどの値をExcelのどこへ出すか

ExcelExporter
    = 実際のExcel書き込み処理
```

特定プロジェクト固有の、

* シート名
* セル位置
* 項目名
* DB名
* テーブル名

などをExcelExporter本体へハードコードしない。

---

# 3. YAMLは機能単位とする

1つの巨大なConcept YAMLを作らない。

例えば、

```text
concepts/
├─ feature_a.yaml
├─ feature_b.yaml
├─ feature_c.yaml
└─ feature_d.yaml
```

のように、システム上の機能単位で分割する。

1ファイルには、その機能を理解・テストするために必要な情報だけを記述する。

---

# 4. YAML基本構造

以下を基本形式とする。

```yaml
schema_version: 1

id: feature:sample

name: サンプル機能

description: >
  この機能が何を行うものか。

concepts:

  - id: sample.input

    name: 入力値

    type: string

    description: >
      この機能で使用する入力値。

    physical:

      - type: database_column

        table: table_a

        column: input_value

  - id: sample.status

    name: 状態

    type: string

    description: >
      この機能上の状態。

    physical:

      - type: database_column

        table: table_a

        column: status

      - type: file

        path: "/path/{id}/status.dat"
```

---

# 5. YAMLの役割

YAMLには以下を記述する。

* 機能名
* 機能概要
* 機能で扱う概念データ
* 各概念データの意味
* 型
* 必要に応じて制約
* 内部実装上の保存先
* DBカラム
* ファイルパス
* API等との関連

Excel上のセル位置は書かない。

---

# 6. Physical情報

ConceptとPhysicalは1対1とは限らない。

そのため `physical` は配列とする。

```yaml
physical:

  - type: database_column
    table: table_a
    column: value

  - type: database_column
    table: table_b
    column: copied_value

  - type: file
    path: "/output/{id}.dat"
```

1つの概念データが複数の内部データに関係していてよい。

---

# 7. 複数Conceptから1つのPhysicalに関係する場合

必要に応じて機能YAML内に `relations` を持てるようにする。

```yaml
relations:

  - id: sample.combined_value

    concepts:
      - sample.value_a
      - sample.value_b

    physical:

      - type: database_column
        table: table_a
        column: combined_value

    description: >
      value_aとvalue_bをもとに内部値が決定される。
```

単純な1対1関係を無理に作らないこと。

---

# 8. 推奨ディレクトリ構成

```text
spec_tool/
├─ main.py
├─ models.py
├─ excel_layout.py
├─ excel_exporter.py
│
├─ concepts/
│  ├─ feature_a.yaml
│  ├─ feature_b.yaml
│  └─ feature_c.yaml
│
├─ layouts/
│  ├─ test_spec_layout.py
│  └─ another_layout.py
│
├─ templates/
│  └─ test_spec.xlsx
│
└─ output/
```

必要以上にクラスやディレクトリを増やさない。

---

# 9. 使用ライブラリ

使用するものは基本的に以下とする。

```text
Python 3.12+
Pydantic 2
PyYAML
openpyxl
pathlib
```

YAMLを書き戻さないため、ruamel.yamlは必須としない。

単純な読み込み用途としてPyYAMLを使用してよい。

---

# 10. Pydanticモデル

YAML構造を検証するためのモデルを作成する。

概念例：

```python
class PhysicalDefinition(BaseModel):
    type: str
    table: str | None = None
    column: str | None = None
    path: str | None = None
    endpoint: str | None = None
    description: str | None = None


class ConceptDefinition(BaseModel):
    id: str
    name: str
    type: str | None = None
    description: str | None = None
    required: bool | None = None
    physical: list[PhysicalDefinition] = []


class FeatureSpecification(BaseModel):
    schema_version: int
    id: str
    name: str
    description: str | None = None
    concepts: list[ConceptDefinition]
```

実際の実装ではMutable Defaultを避けるなど、Pydantic 2として適切に実装すること。

---

# 11. Layoutの役割

Excelのどこへ何を出すかはPythonファイルで定義する。

例：

```python
# layouts/test_spec_layout.py

LAYOUT = {
    "feature_name": {
        "sheet": "概要",
        "cell": "C4",
        "source": "name",
    },

    "feature_description": {
        "sheet": "概要",
        "cell": "C5",
        "source": "description",
    },

    "concepts": {
        "sheet": "項目一覧",
        "start_row": 8,

        "columns": {
            "A": "id",
            "B": "name",
            "C": "type",
            "D": "description",
        },
    },
}
```

このファイルを見ることで、

```text
YAMLのどの情報が
Excelのどこへ出力されるか
```

人間が簡単に確認できるようにする。

---

# 12. Layoutは普通のPythonとしてよい

過度な独自DSLを作らない。

必要なら関数を使用できる。

例えばPhysical情報をExcel表示用文字列へ変換する。

```python
def format_physical(concept):
    values = []

    for physical in concept.physical:

        if physical.type == "database_column":
            values.append(
                f"DB: {physical.table}.{physical.column}"
            )

        elif physical.type == "file":
            values.append(
                f"File: {physical.path}"
            )

    return "\n".join(values)
```

Layoutから、

```python
"physical": {
    "column": "E",
    "formatter": format_physical,
}
```

のように使用できる設計としてよい。

---

# 13. LayoutをPythonにする理由

JSONやYAMLのMappingよりPythonを優先する。

理由：

* セル位置が直接読める
* 条件分岐を書ける
* Formatterを書ける
* 配列展開が簡単
* Excel固有の特殊処理を書きやすい
* 過度なMapping DSLを作らなくて済む

---

# 14. ExcelExporter

ExcelExporterは、

```text
YAMLの意味
```

を知らない汎用的な処理にする。

責務：

1. YAML読み込み
2. Pydantic検証
3. Excelテンプレート読み込み
4. Layout読み込み
5. 指定されたセルへ値設定
6. 一覧データを指定開始行から展開
7. Excel保存

---

# 15. Excelテンプレート

既存Excelをテンプレートとして使用する。

```python
openpyxl.load_workbook(...)
```

で読み込む。

原則として、

* 書式
* 罫線
* 行高
* 列幅
* 印刷設定
* 結合セル
* 数式

等を維持する。

Pythonは必要なセルの値だけを変更する。

---

# 16. 一覧出力

例えばYAMLの、

```yaml
concepts:
  - ...
  - ...
  - ...
```

をExcelへ出力する場合、

Layoutで開始位置を指定する。

```python
"concepts": {
    "sheet": "項目一覧",
    "start_row": 8,

    "columns": {
        "A": "id",
        "B": "name",
        "C": "type",
        "D": "description",
    },
}
```

8行目から順番に出力する。

---

# 17. Formatter

単純なプロパティ取得で表現できない場合のみFormatterを使用する。

例えば、

```python
def format_physical(concept):
    ...
```

など。

ExcelExporter本体にプロジェクト固有処理を書かない。

---

# 18. main.py

大げさなCLIは不要。

例えば以下程度とする。

```python
from pathlib import Path

from excel_exporter import export_excel
from layouts.test_spec_layout import LAYOUT


CONCEPT_FILE = Path(
    "concepts/feature_a.yaml"
)

TEMPLATE_FILE = Path(
    "templates/test_spec.xlsx"
)

OUTPUT_FILE = Path(
    "output/feature_a.xlsx"
)


if __name__ == "__main__":

    export_excel(
        concept_file=CONCEPT_FILE,
        template_file=TEMPLATE_FILE,
        output_file=OUTPUT_FILE,
        layout=LAYOUT,
    )
```

対象機能を変える場合、

```python
CONCEPT_FILE
```

を変更するだけでよい。

---

# 19. 同じLayoutを複数機能で使用可能にする

例えば、

```text
feature_a.yaml
feature_b.yaml
feature_c.yaml
```

が同じExcel様式なら、

すべて同じ、

```text
test_spec_layout.py
```

を使用できること。

---

# 20. 別Excel様式にも対応可能にする

別フォーマットへ出したい場合は、

```text
layouts/
├─ test_spec_layout.py
├─ customer_a_layout.py
└─ customer_b_layout.py
```

のようにLayoutだけ変更する。

YAMLは変更しない。

---

# 21. エラー

最低限、以下を分かりやすくエラー表示する。

* YAMLが存在しない
* YAML構造が不正
* Excelテンプレートが存在しない
* Sheetが存在しない
* Layout指定が不正
* 必須項目が存在しない

---

# 22. テスト

最低限以下を確認する。

### YAML読み込み

正しいYAMLをPydanticモデルへ変換できる。

### YAML不正

必須項目がなければエラーになる。

### セル出力

指定セルへ値が書かれる。

### 一覧出力

conceptsが開始行から順番に出力される。

### Physical整形

複数PhysicalをFormatterによって出力できる。

### テンプレート保持

既存Excelの基本的な書式を破壊しない。

---

# 23. 実装しないもの

以下は不要。

* Excel → YAML
* Backup
* Restore
* ChangeSet
* Excelとの差分検出
* YAML更新
* SQLite
* GUI
* DB接続
* API実行
* 自動テスト実行
* 大規模なCLI

---

# 24. 完了条件

以下を満たせば完成。

* 機能単位YAMLを読み込める
* Pydanticで検証できる
* Physical情報を保持できる
* 1Conceptに複数Physicalを持てる
* Layout.pyでセル位置を確認できる
* Layout.pyで一覧出力を定義できる
* Formatterを書ける
* Excelテンプレートへ出力できる
* 同じLayoutを複数機能で再利用できる
* YAMLを変更せず別Layoutへ出力できる

---

# 25. Copilotへの指示

この文書を仕様として、できるだけ小さく単純なPython基盤を実装すること。

必要以上の抽象化やフレームワーク化を行わないこと。

目的は、

```text
機能単位の仕様YAML
        +
Excel Layout.py
        ↓
既存Excelテンプレート
```

を実現することである。
