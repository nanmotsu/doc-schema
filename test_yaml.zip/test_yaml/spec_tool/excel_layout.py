"""Layout.pyを解釈するための小さな共通処理。"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from pydantic import BaseModel


class LayoutError(Exception):
    """Layout定義またはLayoutを用いた出力に不備がある場合の例外。"""


def get_source_value(item: Any, source: str) -> Any:
    """ドット区切りのsourceからdictまたはPydanticモデルの値を取り出す。"""

    if not isinstance(source, str) or not source:
        raise LayoutError("Layoutのsourceは空でない文字列で指定してください。")

    current = item
    for part in source.split("."):
        if isinstance(current, BaseModel):
            if part not in current.__class__.model_fields:
                raise LayoutError(f"source '{source}' に '{part}' は存在しません。")
            current = getattr(current, part)
        elif isinstance(current, Mapping):
            if part not in current:
                raise LayoutError(f"source '{source}' に '{part}' は存在しません。")
            current = current[part]
        elif isinstance(current, (list, tuple)) and part.isdecimal():
            index = int(part)
            try:
                current = current[index]
            except IndexError as error:
                raise LayoutError(
                    f"source '{source}' の添字 {index} は範囲外です。"
                ) from error
        else:
            raise LayoutError(f"source '{source}' に '{part}' は存在しません。")
    return current


def get_required_string(
    definition: Mapping[str, Any], key: str, context: str
) -> str:
    value = definition.get(key)
    if not isinstance(value, str) or not value:
        raise LayoutError(f"{context} の '{key}' は空でない文字列で指定してください。")
    return value


def get_required_row(definition: Mapping[str, Any], context: str) -> int:
    value = definition.get("start_row")
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise LayoutError(f"{context} の 'start_row' は1以上の整数で指定してください。")
    return value


def get_formatter(
    definition: Mapping[str, Any], context: str
) -> Callable[[Any], Any] | None:
    formatter = definition.get("formatter")
    if formatter is not None and not callable(formatter):
        raise LayoutError(f"{context} の 'formatter' は関数で指定してください。")
    return formatter


def as_cell_value(value: Any, context: str) -> Any:
    """openpyxlへそのまま渡せる値かを確認し、Noneは空欄へ変換する。"""

    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return value
    raise LayoutError(
        f"{context} の値はExcelセルへ直接出力できません "
        f"({type(value).__name__})。formatterを指定してください。"
    )
