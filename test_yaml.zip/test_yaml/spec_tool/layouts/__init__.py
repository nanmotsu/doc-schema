"""Excel様式ごとのLayout定義を配置するパッケージ。"""
