"""標準の仕様書テンプレート用Layoutの例。"""


def format_physical(concept):
    """複数のPhysical情報を、1セルに収まる表示文字列へ整形する。"""

    values = []
    for physical in concept.physical:
        if physical.type == "database_column":
            values.append(f"DB: {physical.table}.{physical.column}")
        elif physical.type == "file":
            values.append(f"File: {physical.path}")
        elif physical.type == "api":
            values.append(f"API: {physical.endpoint}")
        else:
            values.append(f"{physical.type}: {physical.description or ''}".rstrip())
    return "\n".join(values)


LAYOUT = {
    "feature_name": {
        "sheet": "概要",
        "cell": "C4",
        "source": "name",
    },
    "feature_description": {
        "sheet": "概要",
        "cell": "C5",
        "source": "description",
    },
    "concepts": {
        "sheet": "項目一覧",
        "start_row": 8,
        "columns": {
            "A": "id",
            "B": "name",
            "C": "type",
            "D": "description",
            # sourceはキー名から推論されるため、Physical専用Formatterだけ記載できる。
            "physical": {
                "column": "E",
                "formatter": format_physical,
            },
        },
    },
}
