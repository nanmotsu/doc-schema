from __future__ import annotations

from copy import copy
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font

from excel_exporter import LayoutOverlapError, TemplateFileNotFoundError, export_excel
from excel_layout import LayoutError
from models import SpecificationValidationError, load_feature_specification


def format_physical(concept):
    return "\n".join(
        f"DB: {physical.table}.{physical.column}"
        if physical.type == "database_column"
        else f"File: {physical.path}"
        for physical in concept.physical
    )


LAYOUT = {
    "feature_name": {"sheet": "概要", "cell": "C4", "source": "name"},
    "feature_description": {
        "sheet": "概要",
        "cell": "C5",
        "source": "description",
    },
    "concepts": {
        "sheet": "項目一覧",
        "start_row": 8,
        "columns": {
            "A": "id",
            "B": "name",
            "C": "type",
            "D": "description",
            "physical": {"column": "E", "formatter": format_physical},
        },
    },
}


VALID_YAML = """\
schema_version: 1
id: feature:sample
name: サンプル機能
description: 機能の概要
concepts:
  - id: sample.input
    name: 入力値
    type: string
    description: 入力項目
    physical:
      - type: database_column
        table: table_a
        column: input_value
  - id: sample.status
    name: 状態
    type: string
    description: 状態項目
    physical:
      - type: database_column
        table: table_a
        column: status
      - type: file
        path: /work/status.dat
"""


class ExcelExporterTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = TemporaryDirectory()
        self.base_dir = Path(self.temporary_directory.name)
        self.concept_file = self.base_dir / "feature.yaml"
        self.concept_file.write_text(VALID_YAML, encoding="utf-8")
        self.template_file = self.base_dir / "template.xlsx"
        self.output_file = self.base_dir / "nested" / "output.xlsx"

        workbook = Workbook()
        summary = workbook.active
        summary.title = "概要"
        details = workbook.create_sheet("項目一覧")
        details["A8"].font = Font(bold=True, color="FF0000")
        workbook.save(self.template_file)
        workbook.close()

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_loads_valid_yaml_as_pydantic_model(self) -> None:
        feature = load_feature_specification(self.concept_file)

        self.assertEqual(feature.name, "サンプル機能")
        self.assertEqual(len(feature.concepts[1].physical), 2)

    def test_invalid_yaml_without_required_field_raises_readable_error(self) -> None:
        self.concept_file.write_text("schema_version: 1\nid: feature:only\n", encoding="utf-8")

        with self.assertRaises(SpecificationValidationError) as captured:
            load_feature_specification(self.concept_file)

        self.assertIn("name", str(captured.exception))
        self.assertIn("concepts", str(captured.exception))

    def test_exports_cells_rows_formatter_and_preserves_existing_style(self) -> None:
        export_excel(self.concept_file, self.template_file, self.output_file, LAYOUT)

        workbook = load_workbook(self.output_file)
        try:
            self.assertEqual(workbook["概要"]["C4"].value, "サンプル機能")
            self.assertEqual(workbook["概要"]["C5"].value, "機能の概要")
            self.assertEqual(workbook["項目一覧"]["A8"].value, "sample.input")
            self.assertEqual(workbook["項目一覧"]["B9"].value, "状態")
            self.assertEqual(
                workbook["項目一覧"]["E9"].value,
                "DB: table_a.status\nFile: /work/status.dat",
            )
            self.assertTrue(workbook["項目一覧"]["A8"].font.bold)
            self.assertEqual(workbook["項目一覧"]["A8"].font.color.rgb, "00FF0000")
        finally:
            workbook.close()

    def test_reports_missing_template_and_sheet(self) -> None:
        with self.assertRaises(TemplateFileNotFoundError):
            export_excel(
                self.concept_file,
                self.base_dir / "not-found.xlsx",
                self.output_file,
                LAYOUT,
            )

        bad_layout = copy(LAYOUT)
        bad_layout["feature_name"] = {
            "sheet": "存在しないシート",
            "cell": "C4",
            "source": "name",
        }
        with self.assertRaises(LayoutError) as captured:
            export_excel(self.concept_file, self.template_file, self.output_file, bad_layout)
        self.assertIn("存在しないシート", str(captured.exception))

    def test_stops_before_saving_when_write_targets_overlap(self) -> None:
        overlapping_layout = {
            "fixed_value": {
                "sheet": "項目一覧",
                "cell": "A9",
                "source": "name",
            },
            "concepts": {
                "sheet": "項目一覧",
                "start_row": 8,
                "columns": {"A": "id"},
            },
        }

        with self.assertRaises(LayoutOverlapError) as captured:
            export_excel(
                self.concept_file,
                self.template_file,
                self.output_file,
                overlapping_layout,
            )

        message = str(captured.exception)
        self.assertIn("項目一覧", message)
        self.assertIn("A9", message)
        self.assertIn("start_row を 8 から 10 へ変更してください（+2行）", message)
        self.assertFalse(self.output_file.exists())
