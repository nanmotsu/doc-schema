"""仕様YAMLとLayout定義を使ってExcelテンプレートへ値を書き込む。"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.utils.cell import (
    column_index_from_string,
    coordinate_to_tuple,
    get_column_letter,
)

from excel_layout import (
    LayoutError,
    as_cell_value,
    get_formatter,
    get_required_row,
    get_required_string,
    get_source_value,
)
from models import FeatureSpecification, load_feature_specification


class TemplateFileNotFoundError(FileNotFoundError):
    """指定されたExcelテンプレートが存在しない場合の例外。"""


class LayoutOverlapError(LayoutError):
    """Layout内の複数定義が同じExcelセルへ書き込もうとする場合の例外。"""


@dataclass(frozen=True)
class _WriteTarget:
    """Layoutの1定義が書き込む1セルの予定。"""

    sheet: str
    coordinate: str
    layout_name: str
    layout_kind: str
    origin: str


@dataclass(frozen=True)
class _WritePlan:
    """セル定義または一覧定義ひとつ分の書き込み予定。"""

    sheet: str
    layout_name: str
    layout_kind: str
    targets: tuple[_WriteTarget, ...]
    cell: str | None = None
    start_row: int | None = None


def _get_sheet(workbook: Any, sheet_name: str, context: str) -> Any:
    if sheet_name not in workbook.sheetnames:
        available = ", ".join(workbook.sheetnames)
        raise LayoutError(
            f"{context} が指定するSheet '{sheet_name}' はテンプレートにありません。"
            f" 利用可能なSheet: {available}"
        )
    return workbook[sheet_name]


def _validate_column(column: str, context: str) -> str:
    if not isinstance(column, str) or not column:
        raise LayoutError(f"{context} の列はExcel列記号（例: 'A'）で指定してください。")
    try:
        column_index_from_string(column)
    except ValueError as error:
        raise LayoutError(
            f"{context} の列 '{column}' はExcel列記号として不正です。"
        ) from error
    return column.upper()


def _normalise_cell(cell: str, context: str) -> str:
    """セル番地を検証して正規化する。"""

    if not isinstance(cell, str) or not cell:
        raise LayoutError(f"{context} の 'cell' はExcelセル番地（例: 'C4'）で指定してください。")
    try:
        row, column = coordinate_to_tuple(cell.upper())
    except (KeyError, ValueError, TypeError) as error:
        raise LayoutError(f"{context} のセル指定 '{cell}' は不正です。") from error
    if row < 1 or column < 1:
        raise LayoutError(f"{context} のセル指定 '{cell}' は不正です。")
    return f"{get_column_letter(column)}{row}"


def _write_feature_cell(
    workbook: Any, feature: FeatureSpecification, name: str, definition: Mapping[str, Any]
) -> None:
    context = f"Layoutのセル定義 '{name}'"
    sheet_name = get_required_string(definition, "sheet", context)
    cell = _normalise_cell(get_required_string(definition, "cell", context), context)
    source = get_required_string(definition, "source", context)
    formatter = get_formatter(definition, context)

    try:
        value = formatter(feature) if formatter else get_source_value(feature, source)
    except LayoutError:
        raise
    except Exception as error:
        raise LayoutError(f"{context} のformatter実行中に失敗しました: {error}") from error

    worksheet = _get_sheet(workbook, sheet_name, context)
    worksheet[cell] = as_cell_value(value, context)


def _normalise_column_definition(
    key: Any, value: Any, context: str
) -> tuple[str, str, Any]:
    """列定義を (column, source, formatter) に揃える。

    基本形は ``{'A': 'id'}``。Physicalの例のように
    ``{'physical': {'column': 'E', 'formatter': func}}`` も受け付ける。
    """

    if isinstance(value, str):
        return _validate_column(key, context), value, None
    if not isinstance(value, Mapping):
        raise LayoutError(
            f"{context} の列定義 '{key}' はsource文字列または辞書で指定してください。"
        )

    column = value.get("column", key)
    column = _validate_column(column, context)
    source = value.get("source", key)
    if not isinstance(source, str) or not source:
        raise LayoutError(f"{context} の列定義 '{key}' のsourceは文字列で指定してください。")
    return column, source, get_formatter(value, f"{context} の列定義 '{key}'")


def _write_collection(
    workbook: Any, feature: FeatureSpecification, name: str, definition: Mapping[str, Any]
) -> None:
    context = f"Layoutの一覧定義 '{name}'"
    sheet_name = get_required_string(definition, "sheet", context)
    start_row = get_required_row(definition, context)
    source = definition.get("source", name)
    if not isinstance(source, str) or not source:
        raise LayoutError(f"{context} の 'source' は空でない文字列で指定してください。")
    columns = definition.get("columns")
    if not isinstance(columns, Mapping) or not columns:
        raise LayoutError(f"{context} の 'columns' は空でない辞書で指定してください。")

    items = get_source_value(feature, source)
    if not isinstance(items, (list, tuple)):
        raise LayoutError(f"{context} のsource '{source}' は一覧（配列）である必要があります。")
    column_definitions = [
        _normalise_column_definition(key, value, context)
        for key, value in columns.items()
    ]
    worksheet = _get_sheet(workbook, sheet_name, context)

    for offset, item in enumerate(items):
        row = start_row + offset
        for column, item_source, formatter in column_definitions:
            column_context = f"{context} の {row}行目・{column}列"
            try:
                value = formatter(item) if formatter else get_source_value(item, item_source)
            except LayoutError:
                raise
            except Exception as error:
                raise LayoutError(
                    f"{column_context} のformatter実行中に失敗しました: {error}"
                ) from error
            worksheet[f"{column}{row}"] = as_cell_value(value, column_context)


def _collect_write_plans(
    workbook: Any,
    feature: FeatureSpecification,
    layout: Mapping[str, Mapping[str, Any]],
) -> list[_WritePlan]:
    """Layoutを解釈し、書き込み予定セルを収集する（Excelの値は変更しない）。"""

    plans: list[_WritePlan] = []
    for name, definition in layout.items():
        context = f"Layout定義 '{name}'"
        if not isinstance(name, str) or not isinstance(definition, Mapping):
            raise LayoutError(f"{context} は辞書で指定してください。")
        has_cell = "cell" in definition
        has_list = "start_row" in definition
        if has_cell == has_list:
            raise LayoutError(
                f"{context} には 'cell' または 'start_row' のいずれか一方を指定してください。"
            )

        sheet_name = get_required_string(definition, "sheet", context)
        _get_sheet(workbook, sheet_name, context)
        if has_cell:
            cell = _normalise_cell(get_required_string(definition, "cell", context), context)
            plans.append(
                _WritePlan(
                    sheet=sheet_name,
                    layout_name=name,
                    layout_kind="セル定義",
                    cell=cell,
                    targets=(
                        _WriteTarget(sheet_name, cell, name, "セル定義", name),
                    ),
                )
            )
            continue

        start_row = get_required_row(definition, context)
        source = definition.get("source", name)
        if not isinstance(source, str) or not source:
            raise LayoutError(f"{context} の 'source' は空でない文字列で指定してください。")
        columns = definition.get("columns")
        if not isinstance(columns, Mapping) or not columns:
            raise LayoutError(f"{context} の 'columns' は空でない辞書で指定してください。")
        items = get_source_value(feature, source)
        if not isinstance(items, (list, tuple)):
            raise LayoutError(f"{context} のsource '{source}' は一覧（配列）である必要があります。")
        column_definitions = [
            _normalise_column_definition(key, value, context)
            for key, value in columns.items()
        ]
        targets = tuple(
            _WriteTarget(
                sheet_name,
                f"{column}{start_row + row_offset}",
                name,
                "一覧定義",
                f"{name}.{column}",
            )
            for row_offset in range(len(items))
            for column, _, _ in column_definitions
        )
        plans.append(
            _WritePlan(
                sheet=sheet_name,
                layout_name=name,
                layout_kind="一覧定義",
                start_row=start_row,
                targets=targets,
            )
        )
    return plans


def _shift_coordinate_down(coordinate: str, rows: int) -> str:
    row, column = coordinate_to_tuple(coordinate)
    return f"{get_column_letter(column)}{row + rows}"


def _suggest_downward_shift(
    plan: _WritePlan, all_plans: list[_WritePlan]
) -> str:
    """他定義との衝突を避ける最小の下方向シフトを、説明文として返す。"""

    own_coordinates = {target.coordinate for target in plan.targets}
    if len(own_coordinates) != len(plan.targets):
        return (
            f"- {plan.layout_kind} '{plan.layout_name}' の内部で同一セルを重複指定しています。"
            " 列またはセルの指定を変更してください。"
        )

    occupied_by_others = {
        target.coordinate
        for other_plan in all_plans
        if other_plan.sheet == plan.sheet and other_plan.layout_name != plan.layout_name
        for target in other_plan.targets
    }
    maximum_row = max(coordinate_to_tuple(target.coordinate)[0] for target in plan.targets)
    for rows in range(1, 1_048_576 - maximum_row + 1):
        shifted = {
            _shift_coordinate_down(target.coordinate, rows) for target in plan.targets
        }
        if not shifted & occupied_by_others:
            if plan.start_row is not None:
                return (
                    f"- 一覧定義 '{plan.layout_name}' の start_row を "
                    f"{plan.start_row} から {plan.start_row + rows} へ変更してください"
                    f"（+{rows}行）。"
                )
            return (
                f"- セル定義 '{plan.layout_name}' の cell を {plan.cell} から "
                f"{_shift_coordinate_down(plan.cell or '', rows)} へ変更してください"
                f"（+{rows}行）。"
            )
    return (
        f"- {plan.layout_kind} '{plan.layout_name}' は下方向に空きセルを見つけられません。"
        " 列またはシートを変更してください。"
    )


def _raise_if_write_targets_overlap(plans: list[_WritePlan]) -> None:
    """同じシート・セルに複数の書き込み予定があれば、保存前に中止する。"""

    targets_by_cell: dict[tuple[str, str], list[_WriteTarget]] = {}
    for plan in plans:
        for target in plan.targets:
            targets_by_cell.setdefault((target.sheet, target.coordinate), []).append(target)

    conflicts = {
        location: targets
        for location, targets in targets_by_cell.items()
        if len(targets) > 1
    }
    if not conflicts:
        return

    conflict_lines = []
    involved_layouts: set[str] = set()
    for (sheet, coordinate), targets in conflicts.items():
        origins = "、".join(sorted({target.origin for target in targets}))
        conflict_lines.append(f"- Sheet '{sheet}' の {coordinate}: {origins}")
        involved_layouts.update(target.layout_name for target in targets)

    suggestions = [
        _suggest_downward_shift(plan, plans)
        for plan in plans
        if plan.layout_name in involved_layouts
    ]
    raise LayoutOverlapError(
        "Excelの書き込み予定セルが重複しています。出力を中止しました。\n"
        "重複箇所:\n"
        + "\n".join(conflict_lines)
        + "\nずらす候補（下方向）:\n"
        + "\n".join(suggestions)
    )


def export_excel(
    concept_file: Path,
    template_file: Path,
    output_file: Path,
    layout: Mapping[str, Mapping[str, Any]],
) -> FeatureSpecification:
    """仕様YAMLを読み込み、LayoutどおりにExcelテンプレートへ出力する。

    ``layout`` の各要素は ``cell`` を持つセル定義か、``start_row`` を持つ
    一覧定義にする。出力済みの検証済みFeatureSpecificationを返す。
    """

    if not isinstance(layout, Mapping) or not layout:
        raise LayoutError("Layoutは空でない辞書で指定してください。")

    feature = load_feature_specification(Path(concept_file))
    template_file = Path(template_file)
    output_file = Path(output_file)
    if not template_file.is_file():
        raise TemplateFileNotFoundError(
            f"Excelテンプレートが見つかりません: {template_file}"
        )

    try:
        workbook = load_workbook(
            template_file,
            keep_vba=template_file.suffix.lower() == ".xlsm",
        )
    except Exception as error:
        raise LayoutError(
            f"Excelテンプレートを読み込めません: {template_file}\n{error}"
        ) from error

    try:
        plans = _collect_write_plans(workbook, feature, layout)
        _raise_if_write_targets_overlap(plans)

        for name, definition in layout.items():
            if "cell" in definition:
                _write_feature_cell(workbook, feature, name, definition)
            else:
                _write_collection(workbook, feature, name, definition)

        output_file.parent.mkdir(parents=True, exist_ok=True)
        workbook.save(output_file)
    finally:
        workbook.close()

    return feature
