"""対象の仕様YAML・テンプレート・Layoutを差し替えて実行する入口。"""

from pathlib import Path

from excel_exporter import export_excel
from layouts.test_spec_layout import LAYOUT


BASE_DIR = Path(__file__).resolve().parent
CONCEPT_FILE = BASE_DIR / "concepts" / "feature_a.yaml"
TEMPLATE_FILE = BASE_DIR / "templates" / "test_spec.xlsx"
OUTPUT_FILE = BASE_DIR / "output" / "feature_a.xlsx"


if __name__ == "__main__":
    export_excel(
        concept_file=CONCEPT_FILE,
        template_file=TEMPLATE_FILE,
        output_file=OUTPUT_FILE,
        layout=LAYOUT,
    )
    print(f"Excelを出力しました: {OUTPUT_FILE}")
