"""仕様YAMLの読み込みと検証を行うPydanticモデル。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError


class SpecificationError(Exception):
    """仕様YAMLを読み込めない、または検証できない場合の基底例外。"""


class SpecificationFileNotFoundError(SpecificationError):
    """指定された仕様YAMLが存在しない場合の例外。"""


class SpecificationValidationError(SpecificationError):
    """YAMLの構文または構造が仕様に合わない場合の例外。"""


class PhysicalDefinition(BaseModel):
    """ConceptまたはRelationに紐づく内部実装上の保存先。"""

    model_config = ConfigDict(extra="forbid")

    type: str
    table: str | None = None
    column: str | None = None
    path: str | None = None
    endpoint: str | None = None
    description: str | None = None


class ConceptDefinition(BaseModel):
    """機能内で扱う概念データ。"""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    type: str | None = None
    description: str | None = None
    required: bool | None = None
    constraints: dict[str, Any] | None = None
    physical: list[PhysicalDefinition] = Field(default_factory=list)


class RelationDefinition(BaseModel):
    """複数のConceptとPhysicalの関係。"""

    model_config = ConfigDict(extra="forbid")

    id: str
    concepts: list[str] = Field(min_length=1)
    physical: list[PhysicalDefinition] = Field(default_factory=list)
    description: str | None = None


class FeatureSpecification(BaseModel):
    """1機能分の仕様YAML全体。"""

    model_config = ConfigDict(extra="forbid")

    schema_version: int
    id: str
    name: str
    description: str | None = None
    concepts: list[ConceptDefinition]
    relations: list[RelationDefinition] = Field(default_factory=list)


def load_feature_specification(concept_file: Path) -> FeatureSpecification:
    """仕様YAMLを安全に読み込み、検証済みモデルとして返す。"""

    concept_file = Path(concept_file)
    if not concept_file.is_file():
        raise SpecificationFileNotFoundError(
            f"仕様YAMLが見つかりません: {concept_file}"
        )

    try:
        with concept_file.open("r", encoding="utf-8") as stream:
            data = yaml.safe_load(stream)
    except UnicodeDecodeError as error:
        raise SpecificationValidationError(
            f"仕様YAMLをUTF-8として読めません: {concept_file}"
        ) from error
    except yaml.YAMLError as error:
        raise SpecificationValidationError(
            f"仕様YAMLの構文が不正です: {concept_file}\n{error}"
        ) from error

    if not isinstance(data, dict):
        raise SpecificationValidationError(
            "仕様YAMLの最上位はオブジェクト（キーと値の組）である必要があります: "
            f"{concept_file}"
        )

    try:
        return FeatureSpecification.model_validate(data)
    except ValidationError as error:
        raise SpecificationValidationError(
            f"仕様YAMLの構造が不正です: {concept_file}\n{error}"
        ) from error
