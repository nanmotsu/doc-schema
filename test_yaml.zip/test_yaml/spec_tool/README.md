# 仕様YAML → Excel出力基盤

機能単位の仕様YAMLを検証し、既存のExcelテンプレートへ出力する小さな基盤です。ExcelからYAMLへの変換、DB/API接続、独自DSLは扱いません。

## セットアップ

Python 3.12以上で、依存関係を入れます。

```powershell
python -m pip install -r requirements.txt
```

試作用のテンプレート `templates/test_spec.xlsx` を同梱しています。シート `概要` と `項目一覧` を持つため、そのままサンプルLayoutを使えます。実プロジェクトでは、このファイルを既存テンプレートに置き換え、必要に応じてLayoutのシート名・セル位置を変更してください。

```powershell
python main.py
```

`output/feature_a.xlsx` が作成されます。対象を切り替える場合は [main.py](main.py) の3つのPath定数とimportするLayoutを変更します。

## Layoutの書き方

セル出力は `sheet`、`cell`、`source` を指定します。`source` はPydanticモデルの属性名で、ネストした値には `relations.0.id` のようなドット区切りも使えます。

```python
"feature_name": {"sheet": "概要", "cell": "C4", "source": "name"}
```

一覧出力は `start_row` とExcel列記号ごとの項目を指定します。

```python
"concepts": {
    "sheet": "項目一覧",
    "start_row": 8,
    "columns": {"A": "id", "B": "name", "C": "type"},
}
```

項目そのものでは表せない値は、通常のPython関数をFormatterとして使えます。Formatterには一覧の各要素（この例では `ConceptDefinition`）が渡されます。

```python
"physical": {"column": "E", "formatter": format_physical}
```

列記号をキーにする書き方も使えます。

```python
"E": {"source": "physical", "formatter": format_physical}
```

`layouts/test_spec_layout.py` に、複数Physicalを改行で整形する実例があります。Excel書式・罫線・数式等はテンプレートを読み込み、必要なセルの値だけ変更するため維持されます。

## セル重複の防止

出力前に、Layoutから書き込み予定セルをすべて収集します。同じSheetの同じセルを複数のセル定義・一覧定義が使う場合、Excelは保存せず `LayoutOverlapError` で中止します。エラーには重複箇所に加え、各定義を下方向へ何行ずらせば他の定義と重ならないかの候補も表示されます。

たとえば、`start_row: 8` の2行の一覧が `A9` のセル定義と重なる場合、一覧側には `start_row を 8 から 10 へ変更（+2行）` のような候補が表示されます。候補は下方向への最小移動量です。列の重複や定義内部の重複は、Layoutの列指定を変更してください。

## 確認用テスト

標準ライブラリの `unittest` で実行できます。テスト内で一時Excelテンプレートを生成するため、実テンプレートは不要です。

```powershell
python -m unittest discover -s tests -v
```
