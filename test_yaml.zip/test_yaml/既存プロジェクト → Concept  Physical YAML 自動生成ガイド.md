# 既存プロジェクト → 機能単位仕様YAML 作成指示書

## 1. 目的

現在の既存プロジェクトをGitHub Copilotで解析し、

**機能単位の仕様YAML**

を作成する。

生成されたYAMLは、別途用意されたPython基盤によってExcelへ出力する。

この作業ではPythonコードやExcelを作成しない。

---

# 2. 成果物

以下のようなYAMLを作成する。

```text
concepts/
├─ feature_a.yaml
├─ feature_b.yaml
├─ feature_c.yaml
└─ feature_d.yaml
```

1つの巨大なYAMLにまとめない。

---

# 3. 分割単位

YAMLは原則として、

**利用者から見た1つの機能**

を単位とする。

例えば、

```text
一覧表示
登録
変更
削除
検索
取込
出力
設定
```

など、システムの実際の機能構成を確認して分割する。

ただし細かく分けすぎない。

同じ画面・処理の一連の操作として説明できるものは、1機能としてまとめてよい。

---

# 4. ファイルを巨大化させない

1ファイルにシステム全体のConceptを集約しない。

例えば、

```text
system.yaml
```

に全情報を書くのは禁止。

機能ごとに、

```text
feature_a.yaml
feature_b.yaml
```

へ分割する。

---

# 5. 共通データ

同じ概念データが複数機能に登場することは許可する。

ただし、各YAMLには、

**その機能を理解するために必要な情報だけ**

記載する。

別機能の詳細までコピーしない。

例えばある共通値について、

機能Aでは、

```text
識別子
名称
```

しか使用しないのであれば、

機能AのYAMLにはその範囲だけを記載する。

---

# 6. YAML形式

基本形式：

```yaml
schema_version: 1

id: feature:sample

name: サンプル機能

description: >
  この機能が何をするものか。

concepts:

  - id: sample.code

    name: コード

    type: string

    description: >
      この機能上でのコードの意味。

    physical:

      - type: database_column

        table: table_a

        column: code
```

---

# 7. Conceptとは

Conceptは、

**その機能を外部仕様として説明するために必要なデータ**

である。

DBカラムそのものではない。

例えばコード中に、

```text
status_cd
```

があっても、

Concept名をそのまま、

```text
status_cd
```

にするのではなく、

システム上の意味を確認する。

---

# 8. Conceptの判断材料

以下を横断的に確認する。

* 画面
* 入力項目
* 表示項目
* API
* Request
* Response
* Controller
* Handler
* Service
* UseCase
* Model
* Entity
* DTO
* Repository
* DB
* ファイル
* 既存仕様書
* README
* docs

DBだけを見てConceptを作成しない。

---

# 9. Physicalとは

Physicalは、

Conceptが内部実装上どこに存在するかを示す。

対象例：

```text
database_column
file
directory
api_field
config_value
other
```

---

# 10. DBカラム

例：

```yaml
physical:

  - type: database_column

    table: table_a

    column: value_a
```

確認できる場合のみ、

```yaml
data_type: varchar
nullable: false
```

等を追加してよい。

推測してはいけない。

---

# 11. ファイル

実ファイルへ保存される場合：

```yaml
physical:

  - type: file

    path: "/base/{id}/output.dat"
```

動的パスの場合は、実際の1件のパスではなく、

```text
{変数}
```

を使用してパターンを記述する。

---

# 12. 複数Physical

Conceptが複数箇所へ関係する場合、そのまま複数記述する。

```yaml
physical:

  - type: database_column
    table: table_a
    column: value

  - type: database_column
    table: table_b
    column: copied_value

  - type: file
    path: "/output/{id}.dat"
```

1対1に無理やり変換しない。

---

# 13. 複数Conceptから1つの内部値が作られる場合

単純な `physical` では説明できない場合、

`relations` を使用する。

```yaml
relations:

  - id: sample.result

    concepts:
      - sample.value_a
      - sample.value_b

    physical:

      - type: database_column
        table: table_a
        column: result

    description: >
      value_aとvalue_bをもとにresultが決定される。
```

---

# 14. 機能の抽出

まずプロジェクト全体から機能候補を洗い出す。

確認対象：

```text
Routes
Controller
Page
View
Component
API
Menu
Handler
UseCase
Service
```

機能一覧を一度整理してからYAML作成を開始する。

---

# 15. 機能分割の基準

以下がまとまっている場合、1機能として扱いやすい。

* 同じ目的
* 同じ画面
* 同じ処理フロー
* 同じ主要データ
* 同じ利用者操作

逆に目的が明確に異なる場合は分割する。

---

# 16. CRUDを必ず4分割する必要はない

例えば1画面で、

```text
一覧
登録
編集
削除
```

をまとめて扱うシステムなら、

1つの機能YAMLでもよい。

プロジェクトの実際の構造に合わせる。

---

# 17. YAMLを小さく保つ

1機能YAMLが大きくなりすぎた場合、

さらにサブ機能へ分割する。

目安として、

「このYAMLは何の機能を説明しているか」

を一言で答えられなくなった場合は分割を検討する。

---

# 18. Conceptを増やしすぎない

DBカラムをすべてConcept化しない。

例えば、

* 更新日時
* ORM内部用値
* 技術的なフラグ
* キャッシュ制御値
* 内部識別子

などは、

外部仕様やテスト仕様として意味がないのであればConceptに含めなくてよい。

---

# 19. ただしテストに必要なら含める

画面上には表示されなくても、

テスト前提や期待結果として重要な値であればConceptに含めてよい。

判断基準は、

```text
この機能のテスト仕様を書く際に意味があるか
```

とする。

---

# 20. 概念名

Concept IDは安定した英語識別子とする。

例：

```text
sample.code
sample.name
sample.status
```

表示名称は、

```yaml
name:
```

に記載する。

コード上のクラス名やDBカラム名をそのまま外部名称として使用しない。

---

# 21. description

できるだけ、

```yaml
description:
```

を書く。

悪い例：

```yaml
name: 状態
description: 状態
```

良い例：

```yaml
name: 状態

description: >
  この機能で現在どの処理段階にあるかを表す。
```

コードから分かる範囲だけ記述する。

---

# 22. 推測禁止

ソースコードから確認できない仕様は作らない。

判断できない場合は、

* 記述しない
* descriptionに不明点を書く

のどちらかとする。

架空の業務ルールを追加してはいけない。

---

# 23. 値の流れを確認する

Physicalを判断する場合、

可能な範囲で値の流れを追う。

```text
画面
 ↓
Request
 ↓
処理
 ↓
Model / Entity
 ↓
DB / File
```

読み込みの場合も、

```text
DB / File
 ↓
処理
 ↓
DTO / Response
 ↓
画面
```

を確認する。

---

# 24. DBだけで判断しない

例えばDB上に10カラム存在しても、

対象機能が3カラムしか使用していない場合、

その機能YAMLへ10カラムすべてを入れる必要はない。

対象機能との関連が確認できるものだけ記載する。

---

# 25. Physicalパス

ファイルについては、

コード上でパス生成方法を確認する。

例えば、

```python
base / key / "output.xlsx"
```

なら、

```yaml
path: "{base}/{key}/output.xlsx"
```

のように記述する。

---

# 26. API

Conceptとの関係を理解する上で必要な場合はAPIもPhysicalとして記述できる。

```yaml
physical:

  - type: api_field

    method: POST

    endpoint: /api/sample

    location: request

    field: value
```

ただし不要であれば無理に記述しない。

---

# 27. YAML配置

基本：

```text
concepts/
├─ feature_a.yaml
├─ feature_b.yaml
└─ feature_c.yaml
```

必要なら分類用サブディレクトリを使用してよい。

```text
concepts/
├─ group_a/
│  ├─ feature_a.yaml
│  └─ feature_b.yaml
│
└─ group_b/
   └─ feature_c.yaml
```

ファイルパスそのものをIDとして扱わない。

---

# 28. YAML作成手順

以下の順で進める。

```text
1. プロジェクト全体を確認

2. 機能一覧を整理

3. 機能単位を決定

4. 各機能で利用するConceptを抽出

5. 各Conceptの意味を確認

6. 値の保存先・取得元を確認

7. Physicalを記述

8. 必要ならrelationsを記述

9. YAMLを生成

10. 内容を再確認
```

---

# 29. 最初に機能一覧を作る

いきなりYAMLを生成しない。

まず内部的に、

```text
機能A
機能B
機能C
...
```

を整理する。

その後、それぞれのYAMLを作成する。

機能分割がおかしいまま大量のYAMLを生成しないこと。

---

# 30. 共通概念について

共通概念を巨大な `common.yaml` に集約しない。

今回の目的は、

**機能単位でYAMLを読み、そのままExcel仕様書へ出力できること**

である。

したがって各機能YAMLには、その機能の説明に必要な範囲で共通概念を含めてよい。

ただし別機能の不要な項目までコピーしない。

---

# 31. 同じConceptの重複について

機能単位YAMLでは、同じ意味のConceptが複数ファイルに登場してもよい。

これは意図した設計である。

理由は、

```text
1 YAML
=
1機能の外部仕様
```

として独立して読みやすくするため。

ただし同じConceptについて、機能ごとに意味を勝手に変えない。

---

# 32. 生成するのは仕様YAMLのみ

今回Copilotが生成するものは、

```text
concepts/**/*.yaml
```

のみ。

以下は生成しない。

* Python
* Excel
* Layout.py
* テストコード
* DB変更
* Migration
* アプリケーションコード変更

---

# 33. 既存コードを変更しない

この作業は既存プロジェクトの仕様抽出である。

既存コードをリファクタリングしたり、

「改善のため」という理由で変更してはいけない。

---

# 34. 最終確認

各YAMLについて確認する。

### 機能

* 何の機能か分かる
* 他機能まで大量に含めていない

### Concept

* 外部仕様として意味がある
* DBカラムをそのまま並べただけではない
* テスト仕様に利用できる

### Physical

* 実コードで確認できる
* 推測で作っていない
* 複数Physicalを無理に1つへまとめていない

### サイズ

* 1ファイルが巨大化していない
* 必要なら機能をさらに分割している

---

# 35. 完了条件

以下を満たせば完了。

* プロジェクト全体を確認した
* 機能単位を整理した
* 機能ごとにYAMLを作成した
* 各YAMLが単独で機能概要を理解できる
* テスト仕様に使えるConceptを抽出した
* ConceptのPhysical保存先を確認した
* DB以外のファイル等も必要に応じて記述した
* ConceptとPhysicalを1対1と決めつけていない
* YAMLが巨大化していない
* 架空の仕様を追加していない
* 既存コードを変更していない

---

# 36. Copilotへの実行指示

この文書を仕様として、現在のプロジェクトを解析すること。

まず機能一覧を整理した上で、

```text
1機能
=
1つの小さな仕様YAML
```

を基本として `concepts/` 配下へYAMLを生成すること。

YAMLには、

```text
外部仕様としてのConcept
+
そのConceptに関係するPhysical情報
```

を記述すること。

目的は、生成された各YAMLを指定するだけで、別途存在するPython基盤から機能単位のExcel仕様書を何度でも生成できる状態にすることである。
