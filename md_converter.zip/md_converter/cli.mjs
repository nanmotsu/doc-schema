#!/usr/bin/env node

import { spawnSync } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { validateConfigDirectory } from "./src/core/config.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const command = args.shift();

function printHelp() {
    console.log(`md-converter - Markdown document converter

Usage:
  node cli.mjs html <input.md>
  node cli.mjs pdf <input.md> [--keep-html]
  node cli.mjs word <input.md>
  node cli.mjs reverse <input.docx>
  node cli.mjs validate-config

The bundled config in ./config is used by default.
Document frontmatter overrides the bundled defaults.
`);
}

if (!command || command === "--help" || command === "-h") {
    printHelp();
    process.exit(command ? 0 : 1);
}

if (args.includes("--config")) {
    console.error("外部config指定は第1版では未対応です。md-converter/configを編集してください。");
    process.exit(2);
}

if (command === "validate-config") {
    try {
        validateConfigDirectory(join(__dirname, "config"));
        console.log("設定検証OK: md-converter/config");
        process.exit(0);
    } catch (error) {
        console.error(`設定検証エラー: ${error.message}`);
        process.exit(1);
    }
}

const commandScripts = {
    html: "build-pdf.mjs",
    pdf: "build-pdf.mjs",
    word: "build-word.mjs",
    reverse: "reverse.mjs",
};

const scriptName = commandScripts[command];
if (!scriptName) {
    console.error(`未知のコマンドです: ${command}`);
    printHelp();
    process.exit(2);
}

if (command === "html") args.push("--html-only");

const result = spawnSync(process.execPath, [join(__dirname, "src", "commands", scriptName), ...args], {
    stdio: "inherit",
    windowsHide: false,
});

if (result.error) {
    console.error(`コマンド実行エラー: ${result.error.message}`);
    process.exit(1);
}
process.exit(result.status ?? 1);
