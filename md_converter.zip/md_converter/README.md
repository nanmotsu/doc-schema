# md-converter

MarkdownからHTML、PDF、Wordを生成し、WordからMarkdownへ逆変換する独立ツールです。既存プロジェクトの`.tools`や`000_schema`には依存しません。

## Requirements

- Node.js 22以上
- PDFとMermaidを使う場合はChromeまたはChromium
- 日本語文書では日本語フォント（Yu Gothic、Meiryo、Noto Sans JPなど）

## Install

このフォルダを利用先プロジェクトへコピーし、次を実行します。

```powershell
cd md-converter
npm ci
```

Puppeteer管理Chromeを使う場合:

```powershell
npx puppeteer browsers install chrome
```

システムChromeが存在する場合は自動的に優先します。
Chromeの場所を固定する場合は、`PUPPETEER_EXECUTABLE_PATH` に実行ファイルのパスを設定できます。

## CLI

```powershell
node cli.mjs html examples/sample.md
node cli.mjs pdf examples/sample.md
node cli.mjs pdf examples/sample.md --keep-html
node cli.mjs word examples/sample.md
node cli.mjs reverse path\to\document.docx
node cli.mjs validate-config
```

`pdf`は既定ではPDFだけを残し、内部HTMLを削除します。`--keep-html`を付けるとHTMLも保存します。出力先は入力ファイルと同じフォルダが既定です。frontmatterの`htmlOutputDir`、`pdfOutputDir`、`docxOutputDir`と各`*FileName`で変更できます。出力先ディレクトリは事前に作成してください。

## Configuration

設定は「ツールの既定値」と「文書ごとのfrontmatter」の2層です。GUIのフォルダ設定は変換設定とは別物です。

### 変換設定

既定設定は次の3ファイルです。

- `config/page.json`: 用紙、向き、余白、段落設定
- `config/style.json`: フォント、色、見出し番号、タイトルページ
- `config/dsl.json`: `:::figure`、`:::table`、`:::warning`などのDSL

設定を変更すると、その後の変換全体に反映されます。CLIは入力Markdownの場所からプロジェクト設定を自動探索しません。利用先プロジェクトごとに`md-converter/config`を編集してください。

`page.json`は用紙、向き、余白、段落字下げ、TOC深さの既定値です。`style.json`はフォント、色、見出し番号、タイトルページの既定値です。`dsl.json`は`:::figure`、`:::table`、`:::warning`などのDSLブロック定義とスニペット情報です。

画像の相対パスはMarkdownファイルの親フォルダ基準です。`assetsBase`を指定した場合も、そのMarkdownファイルからの相対パスとして解決されます。

### Frontmatter

frontmatterはMarkdownの先頭にYAMLで記述します。指定したキーだけが`config/page.json`または`config/style.json`の値を上書きします。

```yaml
---
title: 利用者管理仕様
subtitle: Markdownから生成した文書
paper: A4
orientation: portrait
margin:
	top: 20mm
	right: 10mm
	bottom: 15mm
	left: 15mm
paragraphIndent: true
toc: true
tocDepth: 3
titlePage: true
headingNumbering: true
assetsBase: ./assets
htmlOutputDir: ./output/html
pdfOutputDir: ./output/pdf
docxOutputDir: ./output/word
htmlFileName: user-management.html
pdfFileName: user-management.pdf
docxFileName: user-management.docx
headerFooter:
	enabled: true
	fontSize: 9px
	footer:
		center: "<span class='pageNumber'></span>/<span class='totalPages'></span>"
orderedListStyle:
	level1: decimal
	level2: paren-upper-alpha
---
```

主な優先順位は次のとおりです。

1. 文書frontmatter
2. `md-converter/config/page.json`、`style.json`、`dsl.json`
3. ツール内部の処理既定値

`headingNumbering`は`style.json`の`heading.numbering`を上書きします。`heading.numbering`もfrontmatterに書けますが、`headingNumbering`が優先されます。`headerFooter`の`header`と`footer`は項目単位で既定値とマージされます。

## DSL

```markdown
:::figure id=login-flow width=70%
![Login flow](assets/login.png)
Login flow
:::

:::table id=user-list
User list

| ID | Name |
| --- | --- |
| 1 | User A |
:::

本文から {{ref:login-flow}} と {{ref:user-list}} で図表を参照できます。
```

参照IDの重複はエラー、未解決の参照は警告として元の文字列を残します。

## Samples

- `examples/sample.md`: Mermaid、図表参照、DSL、改ページのサンプル
- `examples/vscode/tasks.json`: 利用先の`.vscode/tasks.json`へコピーする例
- `examples/.github/skills/markdown-pdf-convert/SKILL.md`: 利用先のSkill配置例

## GUI

GUIはCLIのHTML変換を呼び出すプレビューサーバーとして利用できます。

```powershell
node gui/server.mjs examples
# または
npm run gui -- examples 3355
```

起動後に `http://localhost:3355` を開きます。対象フォルダは`gui/config.json`で複数指定でき、`md-converter`の外にある絶対パスも登録できます。

```json
{
	"port": 3355,
	"folders": [
		{ "id": "project", "label": "Project", "path": "../.." },
		{ "id": "shared-docs", "label": "Shared docs", "path": "D:/shared/docs" }
	]
}
```

相対パスは`gui/config.json`のあるフォルダを基準に解決し、絶対パスはそのまま解決します。GUIの「フォルダ管理」から表示名とパスを追加・削除でき、設定ファイルへ保存されます。削除は登録解除だけで、フォルダやファイル自体は削除しません。

```powershell
node gui/server.mjs --config gui/config.json 3355
```

従来の`node gui/server.mjs path\to\folder 3355`も利用できます。`gui/config.json`が存在する場合は設定ファイルが優先されます。プレビュー用HTMLは一時ファイルとして生成し、画像は登録済みフォルダ内だけを`/api/asset`経由で配信します。PDF/Word出力は既存のCLIタスクを使用します。
