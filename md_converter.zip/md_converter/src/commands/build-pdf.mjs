/**
 * Markdown -> HTML / PDF ビルドスクリプト
 *
 * Usage:
 *   node build.mjs <input.md>              # HTML + PDF を生成
 *   node build.mjs <input.md> --html-only  # HTML のみ生成
 */
import { readFileSync, writeFileSync, existsSync, statSync, unlinkSync } from "fs";
import { join, dirname, basename, extname, resolve } from "path";
import { fileURLToPath, pathToFileURL } from "url";

import { marked } from "marked";
import { transformDSL } from "../core/dsl.mjs";
import { createRequire } from "module";
import {
    generateConfigCSS,
    parseFrontmatter,
    isParagraphIndentEnabled,
    resolveEffectivePageConfig,
    resolveEffectiveStyleConfig,
    resolveDslBodyWithWarnings,
    applyCaptionNumbersToHtml,
    resolveOrderedListStyleConfig,
    applyOrderedListStyleClasses,
    generateOrderedListStyleCSS,
    resolveAssetsBaseAbs,
    resolveCoverPath,
    buildTitlePage,
    buildHeaderFooterOptions,
} from "../core/render_common.mjs";
import { loadToolConfig } from "../core/config.mjs";
import { launchBrowser } from "../core/browser.mjs";

const _require = createRequire(import.meta.url);
const MERMAID_JS = _require.resolve("mermaid/dist/mermaid.min.js");

const __dirname = dirname(fileURLToPath(import.meta.url));

const { dslConfig, styleConfig, pageConfig, structureCss } = loadToolConfig();

/**
 * フロントマターの revisionHistory 配列から改訂履歴ページ HTML を生成する。
 * revisionHistory が配列のときのみ出力する。
 */
function buildRevisionHistoryPage(meta) {
    // revisionHistoryPage: false で非表示 (データを残したまま制御可能)
    if (meta.revisionHistoryPage === false) return "";
    if (!meta.revisionHistory || !Array.isArray(meta.revisionHistory)) return "";
    const rows = meta.revisionHistory;
    // 末尾の改行を除去してから \n を <br> に変換 (YAML の | ブロックスカラー対応)
    const cell = v => String(v ?? "").replace(/\n+$/, "").replace(/\n/g, "<br>");
    const rowsHtml = rows.map(r => [
        `        <tr>`,
        `            <td>${cell(r.version)}</td>`,
        `            <td>${cell(r.date)}</td>`,
        `            <td>${cell(r.author)}</td>`,
        `            <td>${cell(r.description)}</td>`,
        `        </tr>`,
    ].join("\n")).join("\n");
    return [
        '<section class="revision-history">',
        '  <p class="revision-history-title">改訂履歴</p>',
        '  <table>',
        '    <thead>',
        '      <tr>',
        '        <th class="col-version">版</th>',
        '        <th class="col-date">日付</th>',
        '        <th class="col-author">作成者</th>',
        '        <th class="col-description">改訂内容</th>',
        '      </tr>',
        '    </thead>',
        '    <tbody>',
        rowsHtml,
        '    </tbody>',
        '  </table>',
        '</section>',
    ].join("\n");
}

// ── 見出しスラグマップ構築 ───────────────────────────────────
/**
 * 本文 markdown から見出し (h1-h3) を抽出し、slug ID を付与して返す。
 * TOC 生成とカスタムレンダラーで同じ slug を共有するために使用。
 */
function buildSlugMap(markdown) {
    const slugCount = {};
    const headings = [];
    let inCodeBlock = false;
    for (const line of markdown.split(/\r?\n/)) {
        // コードフェンス (``` ) をトグルし、内部の # を見出しとして拾わない。
        if (/^```/.test(line)) { inCodeBlock = !inCodeBlock; continue; }
        if (inCodeBlock) continue;
        const m = line.match(/^(#{1,3})\s+(.+)/);
        if (!m) continue;
        const level = m[1].length;
        const rawText = m[2].trim();
        const textForSlug = rawText
            .replace(/`[^`]*`/g, "")
            .replace(/\*+|_+/g, "")
            .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1")
            .trim();
        const base = textForSlug
            .toLowerCase()
            .replace(/[\s\u3000]+/g, "-")
            .replace(/[^\w\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff\u3400-\u4dbf-]/g, "")
            .replace(/-+/g, "-")
            .replace(/^-|-$/g, "") || "heading";
        const n = slugCount[base] ?? 0;
        slugCount[base] = n + 1;
        headings.push({ level, rawText, slug: n === 0 ? base : `${base}-${n}`, index: headings.length + 1 });
    }
    return headings;
}

/**
 * 見出しリストからリンク付き目次 HTML を生成する。
 * - 既存見出しから自動生成
 * - meta.tocManual がある場合は手入力目次を優先
 * - meta.toc === false の場合は目次を出力しない
 * - tocDepth: 目次に含める最大見出しレベル (1-3)
 *   優先順: フロントマター > page.json > 3 (デフォルト)
 */
function buildTOC(headings, meta, parseFn, effectiveStyleConfig) {
    if (meta.toc === false) return "";

    const manualRaw = meta.tocManual ?? null;
    const hasManualTOC = (typeof manualRaw === "string" && manualRaw.trim() !== "")
        || (Array.isArray(manualRaw) && manualRaw.length > 0);
    if (hasManualTOC) {
        const manualMd = Array.isArray(manualRaw)
            ? manualRaw.map(v => String(v ?? "")).join("\n")
            : String(manualRaw);
        const manualHtml = parseFn(manualMd).trim();
        return [
            '<nav class="toc toc-manual">',
            '  <p class="toc-title">目次</p>',
            '  <div class="toc-manual-body">',
            manualHtml,
            '  </div>',
            '</nav>',
        ].join("\n");
    }

    // tocDepth: フロントマター > page.json > 3
    const rawDepth = meta.tocDepth ?? pageConfig.tocDepth ?? 3;
    const tocDepth = Math.max(1, Math.min(3, parseInt(rawDepth) || 3));

    const filteredHeadings = headings.filter(h => h.level <= tocDepth);
    if (filteredHeadings.length === 0) return "";

    // styleConfig.heading と同じレベル定義で番号を JS 側で再現
    const hs = effectiveStyleConfig.heading;
    const orderedLevels = (hs.levels || ["h1", "h2", "h3"])
        .map(l => parseInt(l.replace("h", "")))
        .filter(n => n >= 1 && n <= 3)
        .sort((a, b) => a - b);
    const counters = {};
    orderedLevels.forEach(l => { counters[l] = 0; });

    const minLevel = Math.min(...filteredHeadings.map(h => h.level));
    const items = filteredHeadings.map(({ level, rawText, index }) => {
        // 番号生成 (CSS カウンターと同じロジック)
        let prefix = "";
        if (hs.numbering && orderedLevels.includes(level)) {
            counters[level]++;
            orderedLevels.filter(l => l > level).forEach(l => { counters[l] = 0; });
            const levelIndex = orderedLevels.indexOf(level);
            const nums = orderedLevels.slice(0, levelIndex + 1).map(cl => counters[cl]);
            prefix = nums.length === 1 ? `${nums[0]}. ` : `${nums.join(".")}.\u0020`;
        }
        const display = rawText
            .replace(/`([^`]*)`/g, "$1")
            .replace(/\*\*([^*]*)\*\*/g, "$1")
            .replace(/\*([^*]*)\*/g, "$1")
            .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1");
        const indent = (level - minLevel) * 1.5;
        // href は数値 ID で固定 (日本語アンカーの PDF 互換性問題を回避)
        return `    <li class="toc-level-${level}" style="padding-left:${indent}em"><a href="#toc-${index}">${prefix}${display}</a></li>`;
    });
    return [
        '<nav class="toc">',
        '  <p class="toc-title">目次</p>',
        '  <ul>',
        ...items,
        '  </ul>',
        '</nav>',
    ].join("\n");
}

// ── CLI 引数 ────────────────────────────────────────────────
const args = process.argv.slice(2);
const inputArg = args.find(a => !a.startsWith("--"));
const htmlOnly = args.includes("--html-only");
const keepHtml = args.includes("--keep-html") || htmlOnly;

if (!inputArg) {
    console.error("Usage: node build.mjs <input.md> [--html-only]");
    process.exit(1);
}

const inputPath = resolve(inputArg);
if (!existsSync(inputPath)) {
    console.error(`ファイルが見つかりません: ${inputPath}`);
    process.exit(1);
}

const srcDir = dirname(inputPath);
const baseName = basename(inputPath, extname(inputPath));

// ── Markdown パーサー ──────────────────────────────────────
marked.setOptions({ gfm: true, breaks: false });
function parseMd(src) {
    return marked.parse(src);
}

/**
 * Mermaid コード先頭のディレクティブを抽出する。
 * 対応:
 *   %%width: 70%%
 *   %%height: 180mm%%
 */
function parseMermaidDirectives(decodedCode) {
    const directives = { width: null, height: null, fontSize: null };
    let code = decodedCode;

    while (true) {
        const m = code.match(/^%%\s*(width|height|fontsize|fontSize)\s*:\s*([^%\r\n]+)\s*%%\s*(?:\r?\n|$)/i);
        if (!m) break;
        const key = m[1].toLowerCase() === "fontsize" ? "fontSize" : m[1].toLowerCase();
        directives[key] = m[2].trim();
        code = code.slice(m[0].length);
    }

    return { code, ...directives };
}

function appendInlineStyleToSvg(svg, styleChunk) {
    if (!styleChunk) return svg;
    if (!/^<svg\b/i.test(svg)) return svg;

    if (/^<svg\b[^>]*\sstyle="/i.test(svg)) {
        return svg.replace(/^<svg\b([^>]*?)\sstyle="([^"]*)"/i, (_m, before, style) =>
            `<svg${before} style="${style}; ${styleChunk}"`
        );
    }

    return svg.replace(/^<svg\b/i, `<svg style="${styleChunk}"`);
}

/**
 * 本文段落の先頭字下げ設定をフロントマターから判定する。
 * 優先順: フロントマター > page.json
 * paragraphIndent を true/on/yes/1 にすると有効。
 */
// render_common.mjs へ共通化済み: parseFrontmatter / resolveEffectivePageConfig / isParagraphIndentEnabled

/**
 * フロントマターから出力ディレクトリを解決する。
 * 優先順: 優先キー > 共通キー (outputDir) > 入力ファイルと同じディレクトリ
 */
function resolveOutputDir(meta, srcDir, preferredKey) {
    const preferred = meta?.[preferredKey];
    const shared = meta?.outputDir;
    const raw = preferred ?? shared;

    if (raw === undefined || raw === null) return srcDir;

    const text = String(raw).trim();
    if (!text) return srcDir;

    return resolve(srcDir, text);
}

function ensureExistingDirectory(pathValue, keyName) {
    if (!existsSync(pathValue)) {
        console.error(`出力ディレクトリが存在しません (${keyName}): ${pathValue}`);
        process.exit(1);
    }

    let isDir = false;
    try {
        isDir = statSync(pathValue).isDirectory();
    } catch {
        isDir = false;
    }

    if (!isDir) {
        console.error(`出力先がディレクトリではありません (${keyName}): ${pathValue}`);
        process.exit(1);
    }
}

function resolveOutputFileName(meta, key, fallback) {
    const raw = meta?.[key];
    if (raw === undefined || raw === null) return fallback;

    const text = String(raw).trim();
    return text || fallback;
}

// ── 変換 ───────────────────────────────────────────────────
const rawMarkdown = readFileSync(inputPath, "utf-8");
const { meta, body } = parseFrontmatter(rawMarkdown);
const effectivePageConfig = resolveEffectivePageConfig(meta, pageConfig);
const effectiveStyleConfig = resolveEffectiveStyleConfig(meta, styleConfig);
const orderedListStyleConfig = resolveOrderedListStyleConfig(meta);

// ── CSS ────────────────────────────────────────────────────
// スキーマから生成した変数・カウンター・DSLクラス CSS + 構造 CSS
const orderedListStyleCss = generateOrderedListStyleCSS(orderedListStyleConfig);
const cssContent = [
    generateConfigCSS({ styleConfig: effectiveStyleConfig, dslConfig, pageCfg: effectivePageConfig }),
    structureCss,
    orderedListStyleCss,
].filter(Boolean).join("\n");

let resolvedBody = body;

try {
    const refResolved = resolveDslBodyWithWarnings(body, effectiveStyleConfig, dslConfig);
    resolvedBody = refResolved.markdown;
    for (const msg of refResolved.warnings) {
        console.warn(`⚠ ${msg}`);
    }
} catch (e) {
    console.error(`参照解決エラー: ${e.message}`);
    process.exit(1);
}

const htmlDir = resolveOutputDir(meta, srcDir, "htmlOutputDir");
const pdfDir = resolveOutputDir(meta, srcDir, "pdfOutputDir");
const htmlFileName = resolveOutputFileName(meta, "htmlFileName", `${baseName}.html`);
const pdfFileName = resolveOutputFileName(meta, "pdfFileName", `${baseName}.pdf`);

ensureExistingDirectory(htmlDir, "htmlOutputDir");
ensureExistingDirectory(pdfDir, "pdfOutputDir");

const htmlPath = join(htmlDir, htmlFileName);
const pdfPath = join(pdfDir, pdfFileName);

// Resolve asset base directory from frontmatter.
// If assetsBase is omitted, use the markdown file directory.
const assetsBaseAbs = resolveAssetsBaseAbs(meta, srcDir);
const assetsCtx = { assetsBaseAbs, dslConfig };

// Resolve cover path.
// Keep absolute URL schemes (https/file/data) as-is.
meta.cover = resolveCoverPath(meta.cover, assetsBaseAbs);

// Build slug map shared by TOC and heading IDs.
const headings = buildSlugMap(resolvedBody);

// bodyHtml 生成後に <h1-3> タグへ id を付与 (数値 ID で PDF との互換性を確保)
const rawBodyHtml = transformDSL(resolvedBody, parseMd, assetsCtx);
let headingPostIndex = 0;
const bodyHtml = rawBodyHtml.replace(/<h([1-3])>/g, (_, lv) => {
    const h = headings[headingPostIndex++];
    return h ? `<h${lv} id="toc-${h.index}">` : `<h${lv}>`;
});


// Mermaid コードブロックを検出・収集し、プレースホルダーに置換。
// ブロック先頭の %%width: 70%% / %%height: 180mm%% ディレクティブでサイズ指定可能。
// 図番号付与は :::figure DSL 側で行うため、ここでは単純に SVG へ置換する。
const mermaidBlocks = [];
const mermaidBlockRegex = /<pre><code class="language-mermaid">([\s\S]*?)<\/code><\/pre>/g;
let processedBodyHtml = bodyHtml.replace(mermaidBlockRegex, (_, code) => {
    const idx = mermaidBlocks.length;
    const decoded = code
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'");
    const { code: cleanCode, width, height, fontSize } = parseMermaidDirectives(decoded);
    mermaidBlocks.push({ idx, code: cleanCode, width, height, fontSize });
    return `__MERMAID_${idx}__`;
});
const hasMermaid = mermaidBlocks.length > 0;
const mermaidDefaultFontSize = effectiveStyleConfig.typography?.fontSize?.body ?? "16px";

processedBodyHtml = applyCaptionNumbersToHtml(processedBodyHtml, effectiveStyleConfig.heading, dslConfig);
processedBodyHtml = applyOrderedListStyleClasses(processedBodyHtml, orderedListStyleConfig);

const titlePageHtml = buildTitlePage(meta);
const revisionHistoryHtml = buildRevisionHistoryPage(meta);
const tocHtml = buildTOC(headings, meta, parseMd, effectiveStyleConfig);
const paragraphIndentEnabled = isParagraphIndentEnabled(meta, effectivePageConfig);
const bodyClass = paragraphIndentEnabled ? ' class="indent-body"' : "";

// タイトル: フロントマター title -> 本文の最初の h1 -> ファイル名
const title = meta.title || resolvedBody.match(/^#\s+(.+)/m)?.[1] || baseName;

// Mermaid は SVG 展開後に静的 HTML へ埋め込むため、スクリプトは不要。
// プレースホルダー入り HTML を先に生成し、後で SVG を埋め込む。

// ── HTML 生成 (Mermaid プレースホルダー入り) ─────────────────
const htmlContent = `<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
${cssContent}
  </style>
</head>
<body${bodyClass}>
${titlePageHtml}
${revisionHistoryHtml}
${tocHtml}
${processedBodyHtml}
</body>
</html>`;

// Mermaid SVG を Puppeteer で生成して HTML に静的埋め込み
let finalHtml = htmlContent;

if (hasMermaid) {
    const browser = await launchBrowser();
    const tmpPage = await browser.newPage();

    // ローカル mermaid.js を注入して SVG を生成 (CDN 不要・オフライン完結)
    // htmlLabels:true かつ foreignObject+HTML で描画し、<br> 改行時の位置ずれを防止
    const mermaidJs = readFileSync(MERMAID_JS, "utf-8");
    await tmpPage.setContent(`<!DOCTYPE html><html><head><meta charset='UTF-8'><style>
* { font-family: 'Meiryo', 'Yu Gothic', 'MS PGothic', sans-serif; }
</style></head><body></body></html>`);
    await tmpPage.evaluate(mermaidJs);
    const baseMermaidConfig = {
        startOnLoad: false,
        theme: 'neutral',
        fontFamily: "'Meiryo', 'Yu Gothic', 'MS PGothic', sans-serif",
        themeVariables: { fontSize: mermaidDefaultFontSize },
        flowchart: { htmlLabels: true },
        sequence: { useMaxWidth: false },
    };

    const svgs = await tmpPage.evaluate(async (blocks, baseConfig) => {
        const out = [];
        for (const { idx, code, fontSize } of blocks) {
            try {
                window.mermaid.initialize({
                    ...baseConfig,
                    themeVariables: {
                        ...baseConfig.themeVariables,
                        fontSize: fontSize || baseConfig.themeVariables.fontSize,
                    },
                });
                const { svg } = await window.mermaid.render(`m${idx}`, code);
                out.push(svg);
            } catch (e) {
                out.push(`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="40"><text fill="red" y="20">Mermaidエラー: ${e.message}</text></svg>`);
            }
        }
        return out;
    }, mermaidBlocks, baseMermaidConfig);

    await tmpPage.close();
    await browser.close();

    // foreignObject の表示を修正する。
    // 問題1: Mermaid は nodeLabel 内部を <span><p>...</p></span> で生成することがある。
    //        ブロック要素 <p> をインライン要素 <span> 内に入れると HTML パーサーの
    //        adoption algorithm により DOM が再構築され、テキストが重なる。
    //        <p> を除去して <br> だけ残せば、<span> 内のインライン改行が正しく機能する。
    // 問題2: Mermaid は div に display:table-cell を設定するが、親に display:table が
    //        ない場合は block 扱いになって縦中央揃えが効かない。
    //        <p> 除去後は <span> を flex アイテムとして扱えるため、flex に置換する。
    //        (<p> がない状態では <span> 内の <br> は flex コンテナ外で作用するため
    //         改行は正しく機能する)
    const fixedSvgs = svgs.map(svg =>
        svg
            // 1) <p> ラッパー除去 (polygon など他の SVG 要素と区別するため \b を使用)
            .replace(/<p\b[^>]*>([\s\S]*?)<\/p>/g, '$1')
            // 2) display:table-cell を flex に置換 (縦横中央揃え)
            .replace(
                /style="display: table-cell;([^"]*)"/g,
                'style="display: flex; align-items: center; justify-content: center; height: 100%;$1"'
            )
    );

    // 取得した SVG を埋め込んでプレースホルダーを置換
    for (let i = 0; i < mermaidBlocks.length; i++) {
        const { width, height } = mermaidBlocks[i];
        const placeholder = `__MERMAID_${i}__`;
        const parentHeightMatch = finalHtml.match(
            new RegExp(`<div class="figure-body"[^>]*style="[^"]*max-height:([^;"]+)[^"]*"[^>]*>[\\s\\S]*?${placeholder}`)
        );
        const effectiveHeight = height || parentHeightMatch?.[1]?.trim() || null;
        const blockStyle = width ? ` style="width:${width};margin:0 auto;"` : '';
        const svgWithHeight = effectiveHeight
            ? appendInlineStyleToSvg(fixedSvgs[i], `max-height:${effectiveHeight};height:auto;max-width:100%;display:block;margin:0 auto;`)
            : fixedSvgs[i];
        finalHtml = finalHtml.replace(placeholder, `<div class="mermaid-block"${blockStyle}>${svgWithHeight}</div>`);
    }
}

// 相対 img src を assetsBaseAbs 起点の絶対 file:/// パスに書き換える。
const absNorm = assetsBaseAbs.replace(/\\/g, "/");
finalHtml = finalHtml.replace(/(<img\b[^>]*?\bsrc=")([^"]+)(")/gi, (_, pre, src, post) => {
    if (/^(https?:|file:|data:)/i.test(src)) return pre + src + post;
    const clean = src.replace(/^\.\//, "");
    return `${pre}${pathToFileURL(resolve(absNorm, clean)).href}${post}`;
});
writeFileSync(htmlPath, finalHtml, "utf-8");
console.log(`出力HTML: ${htmlPath}`);

if (htmlOnly) process.exit(0);

// ── PDF 出力 ───────────────────────────────────────────────
console.log("PDF 生成中...");
const browser = await launchBrowser();
const page = await browser.newPage();

await page.goto(pathToFileURL(htmlPath).href, {
    waitUntil: "networkidle0",
});

await page.pdf({
    path: pdfPath,
    format: effectivePageConfig.paper,
    landscape: effectivePageConfig.orientation === "landscape",
    margin: effectivePageConfig.margin,
    printBackground: true,
    ...buildHeaderFooterOptions(effectivePageConfig),
});

await browser.close();
console.log(`出力PDF:  ${pdfPath}`);

if (!keepHtml && existsSync(htmlPath)) {
    unlinkSync(htmlPath);
}

