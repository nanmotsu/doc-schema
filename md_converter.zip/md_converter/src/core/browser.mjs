import { existsSync } from "node:fs";

const chromeCandidates = [
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium-browser",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
];

export function findChromeExecutable() {
    const configured = process.env.PUPPETEER_EXECUTABLE_PATH;
    if (configured && existsSync(configured)) return configured;
    return chromeCandidates.find(candidate => existsSync(candidate)) ?? null;
}

export async function launchBrowser() {
    const { default: puppeteer } = await import("puppeteer");
    const executablePath = findChromeExecutable();
    return puppeteer.launch({
        headless: true,
        ...(executablePath ? { executablePath } : {}),
    });
}
