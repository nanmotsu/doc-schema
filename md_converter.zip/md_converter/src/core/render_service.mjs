import { spawnSync } from "node:child_process";

export function renderHtmlFile({ cliPath, inputPath, cwd }) {
    const result = spawnSync(process.execPath, [cliPath, "html", inputPath], {
        cwd,
        encoding: "utf-8",
        windowsHide: true,
        maxBuffer: 20 * 1024 * 1024,
    });

    if (result.error) throw result.error;
    if (result.status !== 0) {
        throw new Error((result.stderr || result.stdout || "HTML生成に失敗しました").trim());
    }

    const outputMatch = String(result.stdout || "").match(/出力HTML:\s*(.+)\s*$/m);
    if (!outputMatch) throw new Error("生成HTMLの出力先を特定できませんでした");
    return outputMatch[1].trim();
}
