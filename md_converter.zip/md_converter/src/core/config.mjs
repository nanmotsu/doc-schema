import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { loadConvertConfig } from "./render_common.mjs";

function assertObject(value, pathValue) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new Error(`${pathValue} はオブジェクトで指定してください`);
    }
}

function assertString(value, pathValue) {
    if (typeof value !== "string" || value.trim() === "") {
        throw new Error(`${pathValue} は空でない文字列で指定してください`);
    }
}

function validatePageConfig(config) {
    assertObject(config, "page.json");
    assertString(config.paper, "page.json.paper");
    assertString(config.orientation, "page.json.orientation");
    assertObject(config.margin, "page.json.margin");
    for (const side of ["top", "right", "bottom", "left"]) {
        assertString(config.margin[side], `page.json.margin.${side}`);
    }
}

function validateStyleConfig(config) {
    assertObject(config, "style.json");
    assertObject(config.typography, "style.json.typography");
    assertObject(config.typography.fontSize, "style.json.typography.fontSize");
    assertObject(config.colors, "style.json.colors");
    assertObject(config.heading, "style.json.heading");
}

function validateDslConfig(config) {
    assertObject(config, "dsl.json");
    if (!Array.isArray(config.blocks)) {
        throw new Error("dsl.json.blocks は配列で指定してください");
    }

    const names = new Set();
    for (const [index, block] of config.blocks.entries()) {
        assertObject(block, `dsl.json.blocks[${index}]`);
        assertString(block.name, `dsl.json.blocks[${index}].name`);
        if (names.has(block.name)) {
            throw new Error(`dsl.json.blocks[${index}].name が重複しています: ${block.name}`);
        }
        names.add(block.name);
    }
}

export function validateConvertConfig(config) {
    validatePageConfig(config.pageConfig);
    validateStyleConfig(config.styleConfig);
    validateDslConfig(config.dslConfig);
    return config;
}

export function loadToolConfig() {
    return validateConvertConfig(loadConvertConfig());
}

export function validateConfigDirectory(configDir) {
    for (const fileName of ["page.json", "style.json", "dsl.json"]) {
        const filePath = join(configDir, fileName);
        if (!existsSync(filePath)) {
            throw new Error(`設定ファイルが見つかりません: ${filePath}`);
        }
        try {
            JSON.parse(readFileSync(filePath, "utf-8"));
        } catch (error) {
            throw new Error(`${fileName} のJSONが不正です: ${error.message}`);
        }
    }
    return validateConvertConfig(loadConvertConfig(configDir));
}
