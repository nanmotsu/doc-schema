#!/usr/bin/env node

import { createServer } from "node:http";
import { existsSync, promises as fs } from "node:fs";
import { basename, dirname, extname, isAbsolute, join, relative, resolve } from "node:path";
import { fileURLToPath, fileURLToPath as toFilePath } from "node:url";
import yaml from "js-yaml";
import { parseFrontmatter } from "../src/core/render_common.mjs";
import { renderHtmlFile } from "../src/core/render_service.mjs";
import {
    loadGuiConfig,
    resolveConfiguredFolderPath,
    saveGuiConfig,
    toPublicFolder,
} from "./config.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const toolRoot = resolve(__dirname, "..");
const cliPath = join(toolRoot, "cli.mjs");
const indexPath = join(__dirname, "index.html");
const cliArgs = process.argv.slice(2);
const configArgIndex = cliArgs.indexOf("--config");
const configPath = resolve(
    process.env.MD_CONVERTER_GUI_CONFIG
        || (configArgIndex >= 0 ? cliArgs[configArgIndex + 1] : join(__dirname, "config.json"))
);
const positionalArgs = cliArgs.filter((arg, index) => index !== configArgIndex && index !== configArgIndex + 1 && !arg.startsWith("--"));
const legacyPort = positionalArgs.find(arg => /^\d+$/.test(arg));
const requestedBaseDir = positionalArgs.find(arg => arg !== legacyPort) || resolve(toolRoot, "..");
const guiConfig = await loadGuiConfig(configPath, resolve(requestedBaseDir));
const port = Number(process.env.MD_CONVERTER_GUI_PORT || legacyPort || guiConfig.port || 3355);

function getFolder(folderId) {
    const folder = guiConfig.folders.find(item => item.id === folderId);
    if (!folder) throw new Error(`対象フォルダが見つかりません: ${folderId}`);
    return folder;
}

function isInsideFolder(folderPath, targetPath) {
    const relativePath = relative(folderPath, targetPath);
    return relativePath === ""
        || (relativePath !== ".." && !relativePath.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`) && !isAbsolute(relativePath));
}

function resolveFolderPath(folderId, relativePath, extension = null) {
    const folder = getFolder(folderId);
    const cleanPath = String(relativePath || "").replace(/^[/\\]+/, "");
    const absPath = resolve(folder.absPath, cleanPath);
    if (!isInsideFolder(folder.absPath, absPath)) throw new Error("対象フォルダ外のパスです");
    if (extension && extname(absPath).toLowerCase() !== extension) {
        throw new Error(`対象ファイルは ${extension} である必要があります`);
    }
    return absPath;
}

function findFolderForPath(absPath) {
    return guiConfig.folders.find(folder => isInsideFolder(folder.absPath, absPath));
}

async function collectMarkdownFiles(folder, dir = folder.absPath, result = []) {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
        if (entry.name === "node_modules" || entry.name === ".git") continue;
        const absPath = join(dir, entry.name);
        if (entry.isDirectory()) {
            await collectMarkdownFiles(folder, absPath, result);
        } else if (entry.isFile() && extname(entry.name).toLowerCase() === ".md") {
            result.push({
                folderId: folder.id,
                folderLabel: folder.label,
                path: relative(folder.absPath, absPath).replace(/\\/g, "/"),
            });
        }
    }
    return result.sort((left, right) => left.path.localeCompare(right.path, "ja"));
}

function sendJson(response, status, payload) {
    const body = JSON.stringify(payload);
    response.writeHead(status, {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
    });
    response.end(body);
}

function sendText(response, status, body, contentType = "text/plain; charset=utf-8") {
    response.writeHead(status, { "Content-Type": contentType, "Cache-Control": "no-store" });
    response.end(body);
}

async function readRequestBody(request) {
    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    const body = Buffer.concat(chunks).toString("utf-8");
    if (body.length > 10 * 1024 * 1024) throw new Error("リクエストが大きすぎます");
    return JSON.parse(body || "{}");
}

function rewriteAssetUrls(html) {
    return String(html).replace(/(src|href)=("|')file:\/\/([^"']+)(\2)/gi, (all, attribute, quote, encodedPath) => {
        try {
            const filePath = toFilePath(`file://${encodedPath}`);
            const absPath = resolve(filePath);
            const folder = findFolderForPath(absPath);
            if (!folder) return `${attribute}=${quote}about:blank${quote}`;
            const relativePath = relative(folder.absPath, absPath).replace(/\\/g, "/");
            return `${attribute}=${quote}/api/asset?folderId=${encodeURIComponent(folder.id)}&path=${encodeURIComponent(relativePath)}${quote}`;
        } catch {
            return `${attribute}=${quote}about:blank${quote}`;
        }
    });
}

async function previewMarkdown(folderId, relativePath, content) {
    const sourcePath = resolveFolderPath(folderId, relativePath, ".md");
    const previewName = `.${basename(sourcePath, ".md")}.preview-${process.pid}-${Date.now()}`;
    const previewPath = join(dirname(sourcePath), `${previewName}.md`);
    const previewFileName = `${previewName}.html`;
    const source = String(content).replace(/^\uFEFF/, "");
    const parsed = parseFrontmatter(source);
    const hasValidFrontmatter = parsed.body !== source;
    const meta = hasValidFrontmatter && parsed.meta && typeof parsed.meta === "object" && !Array.isArray(parsed.meta)
        ? parsed.meta
        : {};
    const body = hasValidFrontmatter ? parsed.body : source;
    const previewContent = `---\n${yaml.dump({ ...meta, htmlOutputDir: ".", htmlFileName: previewFileName }, { lineWidth: -1, noRefs: true })}---\n\n${body}`;
    let outputPath = null;
    try {
        await fs.writeFile(previewPath, previewContent, "utf-8");
        outputPath = renderHtmlFile({ cliPath, inputPath: previewPath, cwd: toolRoot });
        return rewriteAssetUrls(await fs.readFile(outputPath, "utf-8"));
    } finally {
        await fs.rm(previewPath, { force: true });
        if (outputPath) await fs.rm(outputPath, { force: true });
    }
}

async function handle(request, response) {
    const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);

    if (request.method === "GET" && url.pathname === "/") {
        return sendText(response, 200, await fs.readFile(indexPath, "utf-8"), "text/html; charset=utf-8");
    }

    if (request.method === "GET" && url.pathname === "/api/config") {
        return sendJson(response, 200, {
            configPath: guiConfig.configPath,
            folders: guiConfig.folders.map(toPublicFolder),
            defaultFolderId: guiConfig.folders[0]?.id || null,
        });
    }

    if (request.method === "GET" && url.pathname === "/api/files") {
        const folderId = url.searchParams.get("folderId");
        const folders = folderId ? [getFolder(folderId)] : guiConfig.folders;
        const files = [];
        for (const folder of folders) await collectMarkdownFiles(folder, folder.absPath, files);
        return sendJson(response, 200, { files });
    }

    if (request.method === "GET" && url.pathname === "/api/file") {
        const folderId = url.searchParams.get("folderId");
        const relativePath = url.searchParams.get("path");
        const filePath = resolveFolderPath(folderId, relativePath, ".md");
        return sendJson(response, 200, {
            folderId,
            path: relativePath,
            content: await fs.readFile(filePath, "utf-8"),
        });
    }

    if (request.method === "GET" && url.pathname === "/api/asset") {
        const filePath = resolveFolderPath(url.searchParams.get("folderId"), url.searchParams.get("path"));
        const content = await fs.readFile(filePath);
        const contentType = {
            ".css": "text/css",
            ".gif": "image/gif",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".svg": "image/svg+xml",
            ".webp": "image/webp",
        }[extname(filePath).toLowerCase()] || "application/octet-stream";
        response.writeHead(200, { "Content-Type": contentType, "Cache-Control": "no-store" });
        return response.end(content);
    }

    if (request.method === "POST" && url.pathname === "/api/file") {
        const payload = await readRequestBody(request);
        const filePath = resolveFolderPath(payload.folderId, payload.path, ".md");
        await fs.writeFile(filePath, String(payload.content ?? ""), "utf-8");
        return sendJson(response, 200, { folderId: payload.folderId, path: payload.path, saved: true });
    }

    if (request.method === "POST" && url.pathname === "/api/preview") {
        const payload = await readRequestBody(request);
        const html = await previewMarkdown(payload.folderId, payload.path, String(payload.content ?? ""));
        return sendJson(response, 200, { html });
    }

    if (request.method === "POST" && url.pathname === "/api/folders") {
        const payload = await readRequestBody(request);
        const absPath = resolveConfiguredFolderPath(guiConfig, payload.path);
        if (!existsSync(absPath)) throw new Error(`フォルダが見つかりません: ${absPath}`);
        const stat = await fs.stat(absPath);
        if (!stat.isDirectory()) throw new Error(`フォルダではありません: ${absPath}`);
        if (guiConfig.folders.some(folder => folder.absPath === absPath)) throw new Error("同じフォルダは既に登録されています");
        const idBase = String(payload.id || payload.label || basename(absPath) || "folder")
            .toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "") || "folder";
        let id = idBase;
        let suffix = 2;
        while (guiConfig.folders.some(folder => folder.id === id)) id = `${idBase}-${suffix++}`;
        const folderPath = String(payload.path).trim();
        const next = await saveGuiConfig(guiConfig, [
            ...guiConfig.folders,
            { id, label: String(payload.label || basename(absPath) || id).trim(), path: folderPath, absPath },
        ]);
        guiConfig.folders = next.folders;
        return sendJson(response, 200, { folder: toPublicFolder(guiConfig.folders.find(folder => folder.id === id)) });
    }

    if (request.method === "DELETE" && url.pathname === "/api/folders") {
        const folderId = url.searchParams.get("id");
        if (guiConfig.folders.length <= 1) throw new Error("最後のフォルダは削除できません");
        getFolder(folderId);
        const next = await saveGuiConfig(guiConfig, guiConfig.folders.filter(folder => folder.id !== folderId));
        guiConfig.folders = next.folders;
        return sendJson(response, 200, { removed: folderId });
    }

    sendText(response, 404, "Not found");
}

const server = createServer((request, response) => {
    handle(request, response).catch(error => {
        console.error(error);
        sendJson(response, 400, { error: error.message });
    });
});

server.listen(port, "127.0.0.1", () => {
    console.log(`md-converter GUI: http://localhost:${port}`);
    console.log(`GUI config: ${guiConfig.configPath}`);
    console.log(`対象フォルダ: ${guiConfig.folders.map(folder => folder.absPath).join(", ") || "なし"}`);
});
