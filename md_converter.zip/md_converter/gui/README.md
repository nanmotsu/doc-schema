# GUI

The GUI is a small local preview server. It delegates Markdown rendering to `cli.mjs html`, so preview and CLI output use the same DSL, numbering, frontmatter, and asset rules.

## Start

```powershell
node md-converter/gui/server.mjs --config md-converter/gui/config.json 3355
```

The default port is `3355`. Set `MD_CONVERTER_GUI_PORT` or pass a final numeric argument to change it. `MD_CONVERTER_GUI_CONFIG` can also specify the config path.

## Folder configuration

`gui/config.json` controls the directories visible to the GUI. Relative paths are resolved from the config file directory; absolute paths can point outside `md-converter`.

```json
{
	"port": 3355,
	"folders": [
		{ "id": "project", "label": "Project", "path": "../.." },
		{ "id": "shared", "label": "Shared docs", "path": "D:/shared/docs" }
	]
}
```

The GUI folder manager can add and remove registered folders. Removing a folder only changes `config.json`; it does not delete data. The server accepts `--config path/to/config.json` for a different configuration file.

## Responsibilities

- Markdown file selection and editing
- Save to the selected Markdown file
- HTML preview through the CLI renderer
- Local asset serving restricted to the selected base directory
- Multiple configured folders, including folders outside `md-converter`
- Folder registration and removal from the GUI

The GUI does not implement its own DSL parser, heading numbering, PDF renderer, or Word renderer.

## Security boundary

- The server binds to `127.0.0.1`.
- File, save, and asset paths must remain under one of the configured folders.
- Preview frontmatter output settings are replaced with a temporary HTML destination.
- The preview iframe uses a sandbox and does not allow scripts from generated HTML.
