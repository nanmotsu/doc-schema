import { existsSync, promises as fs, statSync } from "node:fs";
import { basename, dirname, isAbsolute, join, resolve } from "node:path";

const DEFAULT_CONFIG = {
    port: 3355,
    folders: [],
};

function createFolderId(label, index = 0) {
    const base = String(label || "folder")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9_-]+/g, "-")
        .replace(/^-+|-+$/g, "") || "folder";
    return `${base}-${index + 1}`;
}

function normalizeFolder(folder, index, configDir) {
    if (!folder || typeof folder !== "object") throw new Error(`folders[${index}] はオブジェクトで指定してください`);
    const rawPath = String(folder.path || "").trim();
    if (!rawPath) throw new Error(`folders[${index}].path は必須です`);
    const absPath = resolve(configDir, rawPath);
    if (!existsSync(absPath)) throw new Error(`フォルダが見つかりません: ${rawPath}`);
    if (!statSync(absPath).isDirectory()) throw new Error(`フォルダではありません: ${rawPath}`);
    const id = String(folder.id || createFolderId(folder.label || basename(absPath), index)).trim();
    const label = String(folder.label || basename(absPath) || id).trim();
    return { id, label, path: rawPath, absPath };
}

export async function loadGuiConfig(configPath, fallbackRoot = process.cwd()) {
    const configDir = dirname(configPath);
    let raw = DEFAULT_CONFIG;
    if (existsSync(configPath)) {
        try {
            raw = JSON.parse(await fs.readFile(configPath, "utf-8"));
        } catch (error) {
            throw new Error(`GUI config.json のJSONが不正です: ${error.message}`);
        }
    } else {
        raw = {
            ...DEFAULT_CONFIG,
            folders: [{ id: "project", label: "Project", path: fallbackRoot }],
        };
    }

    if (!Array.isArray(raw.folders)) throw new Error("GUI config.json のfoldersは配列で指定してください");
    const folders = raw.folders.map((folder, index) => normalizeFolder(folder, index, configDir));
    const ids = new Set();
    for (const folder of folders) {
        if (ids.has(folder.id)) throw new Error(`GUI config.json のfolder idが重複しています: ${folder.id}`);
        ids.add(folder.id);
    }

    return {
        port: Number(raw.port) || 3355,
        folders,
        configPath,
        configDir,
    };
}

export async function saveGuiConfig(config, folders) {
    const rawFolders = folders.map(({ id, label, path }) => ({ id, label, path }));
    const output = {
        port: config.port,
        folders: rawFolders,
    };
    await fs.writeFile(config.configPath, `${JSON.stringify(output, null, 4)}\n`, "utf-8");
    return loadGuiConfig(config.configPath);
}

export function resolveConfiguredFolderPath(config, rawPath) {
    const value = String(rawPath || "").trim();
    if (!value) throw new Error("フォルダパスを指定してください");
    return isAbsolute(value) ? resolve(value) : resolve(config.configDir, value);
}

export function toPublicFolder(folder) {
    return { id: folder.id, label: folder.label, path: folder.absPath };
}
