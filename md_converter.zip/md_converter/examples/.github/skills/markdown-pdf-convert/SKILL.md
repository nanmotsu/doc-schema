---
name: markdown-pdf-convert
description: "Use when converting Markdown to HTML, PDF, or Word with md-converter. Covers frontmatter, config/page.json, config/style.json, config/dsl.json, figure/table DSL, references, assetsBase, output commands, and GUI folder configuration."
---

# Markdown conversion rules

Use the independent `md-converter` directory. It owns conversion defaults under `md-converter/config` and GUI folder access under `md-converter/gui/config.json`; do not reference the source project's `000_schema`.

## Commands

```powershell
node md-converter/cli.mjs html <target.md>
node md-converter/cli.mjs pdf <target.md>
node md-converter/cli.mjs pdf <target.md> --keep-html
node md-converter/cli.mjs word <target.md>
node md-converter/cli.mjs reverse <target.docx>
```

## Configuration precedence

- Document frontmatter overrides the bundled conversion defaults.
- `md-converter/config/page.json` supplies paper, orientation, margins, paragraph indentation, and TOC defaults.
- `md-converter/config/style.json` supplies typography, colors, heading numbering, and title-page defaults.
- `md-converter/config/dsl.json` defines `:::figure`, `:::table`, `:::pagebreak`, `:::warning`, and other DSL blocks.
- The CLI does not auto-discover a project config outside `md-converter/config`.

## Frontmatter

Use YAML frontmatter at the top of the Markdown file for document-specific settings:

```yaml
---
title: User management specification
subtitle: Generated from Markdown
paper: A4
orientation: portrait
margin:
	top: 20mm
	right: 10mm
	bottom: 15mm
	left: 15mm
paragraphIndent: true
toc: true
tocDepth: 3
titlePage: true
headingNumbering: true
assetsBase: ./assets
htmlOutputDir: ./output/html
pdfOutputDir: ./output/pdf
docxOutputDir: ./output/word
---
```

`assetsBase` and output directories are resolved relative to the Markdown file. Output directories must already exist. `headingNumbering` overrides `style.json` and `headerFooter` values are merged by section.

## Rules

- Use `:::figure` for images, Mermaid, and code figures.
- Use `:::table` for numbered tables.
- Add unique `id` attributes when the body needs a figure/table reference.
- Use `{{ref:id}}` or `[[ref:id]]` in the body.
- Relative assets are resolved from the Markdown file's directory unless `assetsBase` is specified.
- Document frontmatter overrides the bundled page and style defaults.
- Create output directories before using `htmlOutputDir`, `pdfOutputDir`, or `docxOutputDir`.

## GUI folders

The GUI reads `md-converter/gui/config.json`. Relative folder paths are resolved from that file; absolute paths may point outside `md-converter`.

```json
{
	"folders": [
		{ "id": "project", "label": "Project", "path": "../.." },
		{ "id": "shared", "label": "Shared docs", "path": "D:/shared/docs" }
	]
}
```

Start it with `node md-converter/gui/server.mjs --config md-converter/gui/config.json 3355`. The GUI can register and remove folders, but removal only unregisters the path and never deletes its files.
