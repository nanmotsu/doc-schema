---
title: Markdown Converter Sample
subtitle: Independent PDF and Word conversion example
assetsBase: ./assets
htmlOutputDir: .
pdfOutputDir: .
docxOutputDir: .
paper: A4
orientation: portrait
toc: true
titlePage: true
headingNumbering: true
paragraphIndent: true
---

# Conversion overview

This sample exercises the independent converter without depending on the source project.

## Markdown elements

- Lists
- **Emphasis**
- `inline code`

:::warning
This is a configurable DSL block.
:::

# Diagram and table

The process is shown in {{ref:fig-pipeline}} and the result is listed in {{ref:tbl-output}}.

:::figure id=fig-overview width=80%
![Conversion overview](overview.svg)
Independent converter input and output flow
:::

:::figure id=fig-pipeline width=80%
```mermaid
flowchart LR
    A[Markdown] --> B[HTML]
    B --> C{Output}
    C --> D[PDF]
    C --> E[Word]
```
Independent conversion pipeline
:::

:::table id=tbl-output colRatio=1,2
Output format

| Format | Command |
| --- | --- |
| PDF | `node cli.mjs pdf examples/sample.md` |
| Word | `node cli.mjs word examples/sample.md` |
:::

:::pagebreak
:::

# Final section

The same source can produce HTML, PDF, and Word documents.
