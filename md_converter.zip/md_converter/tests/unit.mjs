import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

import {
    loadToolConfig,
    validateConfigDirectory,
} from "../src/core/config.mjs";
import {
    parseFrontmatter,
    resolveEffectivePageConfig,
    resolveEffectiveStyleConfig,
    resolveDslBodyWithWarnings,
} from "../src/core/render_common.mjs";
import { loadGuiConfig } from "../gui/config.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const configDir = join(__dirname, "..", "config");
const config = loadToolConfig();
const guiConfig = await loadGuiConfig(join(__dirname, "..", "gui", "config.json"));

validateConfigDirectory(configDir);
assert.equal(guiConfig.folders.length, 1);
assert.equal(guiConfig.folders[0].id, "project");

const parsed = parseFrontmatter("\uFEFF---\nmargin:\n  top: 20mm\n---\n# Title\n");
assert.equal(parsed.meta.margin.top, "20mm");
assert.equal(parsed.body, "# Title\n");

const page = resolveEffectivePageConfig({
    margin: { top: "20mm" },
    headerFooter: {
        enabled: true,
        footer: { center: "<span class='pageNumber'></span>" },
    },
}, {
    ...config.pageConfig,
    headerFooter: {
        enabled: false,
        fontSize: "9px",
        header: { left: "Document" },
        footer: { right: "Example" },
    },
});
assert.equal(page.margin.top, "20mm");
assert.equal(page.margin.left, config.pageConfig.margin.left);
assert.equal(page.headerFooter.enabled, true);
assert.equal(page.headerFooter.header.left, "Document");
assert.equal(page.headerFooter.footer.center, "<span class='pageNumber'></span>");
assert.equal(page.headerFooter.footer.right, "Example");

const style = resolveEffectiveStyleConfig({ headingNumbering: false }, config.styleConfig);
assert.equal(style.heading.numbering, false);
assert.equal(config.styleConfig.heading.numbering, true);

const resolved = resolveDslBodyWithWarnings(
    "# Section\n\nSee {{ref:fig-a}} and {{ref:missing}}.\n\n:::figure id=fig-a\nCaption\n:::\n",
    config.styleConfig,
    config.dslConfig,
);
assert.match(resolved.markdown, /図1\.1/);
assert.deepEqual(resolved.warnings, ["未解決参照: missing"]);

assert.throws(
    () => resolveDslBodyWithWarnings(
        ":::figure id=duplicate\nOne\n:::\n\n:::figure id=duplicate\nTwo\n:::\n",
        config.styleConfig,
        config.dslConfig,
    ),
    /参照IDが重複しています/,
);

console.log("unit tests passed");