# Technology Upgrade Knowledge Base 設計書

## 1. 概要

各種技術製品・フレームワーク・ランタイム・DB・ライブラリについて、バージョンアップ時に必要となる変更情報を収集・構造化する。

対象技術を特定の言語・製品に限定しない。

想定例：

```text
Language / Runtime
├─ PHP
├─ .NET
├─ Node.js
├─ Python
└─ Java

Framework
├─ Laravel
├─ ASP.NET Core
├─ Entity Framework Core
├─ Vue
└─ React

Database
├─ PostgreSQL
├─ MariaDB
├─ SQL Server
└─ SQLite

Extension / Engine
├─ Mroonga
├─ PostGIS
└─ pgvector

Package
├─ Composer
├─ NuGet
├─ npm
└─ その他

Tool / Infrastructure
├─ Nginx
├─ Docker
└─ GitHub Actions
```

蓄積した一般知識と、実際のプロジェクトの状態を組み合わせ、

```text
変更情報収集
    ↓
対象プロジェクトの構成解析
    ↓
該当する変更点を検索
    ↓
影響箇所を検出
    ↓
対応方針を決定
    ↓
コード・設定・DB等を変更
    ↓
検証
    ↓
作業記録
    ↓
作業報告書
```

までを支援する。

---

# 2. 基本思想

システムを大きく、

```text
Knowledge

Project

Index
```

の3領域に分ける。

```mermaid
flowchart LR

    subgraph KB["Knowledge / 一般事実"]
        Product[製品]
        Version[Version]
        Change[変更事項]
        Target[影響対象]
        Alternative[代替方法]
        Compatibility[互換性]
    end

    subgraph PROJECT["Project / 個別事実"]
        Component[使用製品]
        Usage[使用箇所]
        Match[該当変更]
        Decision[対応判断]
        Work[作業]
        Verification[検証]
    end

    subgraph INDEX["Index / 派生データ"]
        FTS[FTS5]
        Vector[Vector Index]
    end

    KB --> PROJECT
    KB --> INDEX
```

---

# 3. 一般事実とプロジェクト情報

## Knowledge

どのプロジェクトにも共通する事実。

例：

```text
PHP 8.2でDynamic PropertyがDeprecated

.NETの特定APIがObsolete

ASP.NET CoreでHosting Modelが変更

EF CoreのQuery挙動が変更

PostgreSQLで設定項目が削除

PostgreSQL Extensionの対応Versionが変更

Mroongaのparser構文が削除

NuGet Package AのAPIがVersion 5で削除
```

---

## Project

特定システムについてのみ成り立つ情報。

例：

```text
このプロジェクトでは.NET 8を使用

EF Core 8.0.4を使用

PostgreSQL 16を使用

Npgsql 8.0.2を使用

削除されたAPIをFooService.csで使用

PostgreSQLの削除設定はpostgresql.confでは未使用

Package Aは廃止してPackage Bに変更

dotnet testが成功
```

---

# 4. 最重要原則

一般事実とプロジェクト判断を混ぜない。

例えば、

```text
.NET 10でFoo APIが削除
```

は一般事実。

```text
このシステムではFoo APIをBar APIへ置換する
```

はProject Decision。

```text
FooService.csをBar APIへ修正した
```

はWork Log。

```text
dotnet test成功
```

はVerification。

したがって、

```mermaid
flowchart LR

    K[Knowledge]
    M[Match]
    D[Decision]
    W[Work]
    V[Verification]

    K --> M
    M --> D
    D --> W
    W --> V
```

の5段階で管理する。

---

# 5. SQLite

SQLiteを唯一の正本とする。

```text
data/
└─ upgrade.sqlite
```

内部は、

```text
kb_*
project_*
idx_*
```

で論理的に分離する。

```text
kb_*       一般知識

project_*  プロジェクト情報

idx_*      FTS / Embedding / Vectorなど
```

当面はSQLiteファイルを分割しない。

理由：

```text
JOINしやすい

Backupが簡単

MCPから扱いやすい

CLI/Webで共有しやすい

KnowledgeとProjectの関連付けが容易
```

---

# 6. 技術構成

| 用途 | 技術 |
|---|---|
| Language | TypeScript |
| Runtime | Node.js |
| Database | SQLite |
| Driver | better-sqlite3 |
| 全文検索 | SQLite FTS5 |
| Vector | sqlite-vec |
| Embedding | Ruri v3 30m |
| Embedding Runtime | Transformers.js |
| CLI | Commander |
| API | Fastify |
| Web | Vue 3 + Vite |
| Validation | Zod |
| Test | Vitest |
| MCP | TypeScript MCP SDK |

Pythonは使用しない。

---

# 7. 全体アーキテクチャ

```mermaid
flowchart TB

    subgraph SOURCE["External Sources"]
        Docs[Official Documentation]
        Release[Release Notes]
        Migration[Migration / Upgrade Guides]
        PackageRegistry[Package Registries]
        Repository[Git Repositories]
    end

    subgraph IMPORT["Import Layer"]
        Discovery[Source Discovery]
        Fetcher[Fetcher]
        Parser[Parser]
        Extractor[Change Extractor]
        Normalizer[Normalizer]
        Reviewer[Reviewer]
    end

    subgraph CORE["Application Core"]
        KnowledgeService[Knowledge Service]
        SearchService[Search Service]
        ProjectService[Project Service]
        DecisionService[Decision Service]
        WorkService[Work Service]
        ReportService[Report Service]
    end

    KB[(kb_* Tables)]
    PROJECT[(project_* Tables)]

    FTS[FTS5]
    Ruri[Ruri v3 30m]
    Vec[sqlite-vec]

    CLI[CLI]
    API[Fastify API]
    Web[Vue]
    MCP[MCP Server]
    Copilot[GitHub Copilot]

    SOURCE --> IMPORT
    IMPORT --> KB

    KB --> FTS
    KB --> Ruri
    Ruri --> Vec

    FTS --> SearchService
    Vec --> SearchService
    KB --> SearchService

    CORE --> KB
    CORE --> PROJECT

    CLI --> CORE
    Web --> API
    API --> CORE

    Copilot --> MCP
    MCP --> CORE
```

---

# 8. 汎用的な製品モデル

個別製品名をテーブルとして作らない。

すべて、

```text
Product
Version
```

として扱う。

例えば、

```text
Product
├─ PHP
├─ Laravel
├─ .NET
├─ ASP.NET Core
├─ EF Core
├─ PostgreSQL
├─ Npgsql
├─ MariaDB
├─ Mroonga
├─ Newtonsoft.Json
└─ Guzzle
```

である。

---

# 9. `kb_products`

```sql
CREATE TABLE kb_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    ecosystem TEXT,

    product_type TEXT NOT NULL,

    vendor TEXT,

    name TEXT NOT NULL,

    package_identifier TEXT,

    repository_url TEXT,
    homepage_url TEXT,

    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,

    UNIQUE(ecosystem, name)
);
```

---

# 10. product_type

製品の分類。

```text
language
runtime
framework
database
database-extension
library
package
server
tool
platform
other
```

例：

| Product | product_type |
|---|---|
| PHP | runtime |
| .NET | runtime |
| Laravel | framework |
| ASP.NET Core | framework |
| EF Core | framework |
| PostgreSQL | database |
| MariaDB | database |
| Mroonga | database-extension |
| PostGIS | database-extension |
| Npgsql | library |
| Newtonsoft.Json | library |

---

# 11. ecosystem

Package ecosystem等を表現する。

```text
composer
nuget
npm
maven
pip
system
```

例えば、

```text
guzzlehttp/guzzle
ecosystem = composer

Npgsql
ecosystem = nuget

@vue/runtime-core
ecosystem = npm
```

---

# 12. `kb_product_versions`

```sql
CREATE TABLE kb_product_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    product_id INTEGER NOT NULL,

    version TEXT NOT NULL,
    normalized_version TEXT,

    release_date TEXT,

    support_status TEXT,

    requirements_json TEXT,

    metadata_json TEXT,

    FOREIGN KEY(product_id)
        REFERENCES kb_products(id)
        ON DELETE CASCADE,

    UNIQUE(product_id, version)
);
```

`requirements_json`には例えば、

```json
{
  "dotnet": ">=8.0",
  "postgresql": ">=14"
}
```

のような情報を保持できる。

---

# 13. 公式情報

## `kb_sources`

公式資料を保存する。

```sql
CREATE TABLE kb_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    product_id INTEGER NOT NULL,

    from_version_id INTEGER,
    to_version_id INTEGER,

    source_type TEXT NOT NULL,

    title TEXT NOT NULL,

    source_url TEXT NOT NULL,
    source_anchor TEXT,

    raw_content TEXT NOT NULL,
    normalized_text TEXT NOT NULL,

    content_hash TEXT NOT NULL,

    fetched_at TEXT NOT NULL,
    created_at TEXT NOT NULL,

    FOREIGN KEY(product_id)
        REFERENCES kb_products(id),

    UNIQUE(source_url, content_hash)
);
```

---

# 14. source_type

```text
upgrade-guide
migration-guide
breaking-changes
release-note
changelog
deprecation-list
compatibility-guide
package-metadata
documentation
other
```

---

# 15. `kb_changes`

システムの中心。

**1変更 = 1レコード**

とする。

```sql
CREATE TABLE kb_changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    stable_key TEXT NOT NULL UNIQUE,

    product_id INTEGER NOT NULL,

    source_id INTEGER NOT NULL,

    from_version_id INTEGER,
    to_version_id INTEGER,

    deprecated_since_version_id INTEGER,
    removed_since_version_id INTEGER,

    category TEXT,

    change_type TEXT NOT NULL,
    impact TEXT NOT NULL DEFAULT 'unknown',

    title TEXT NOT NULL,

    summary_ja TEXT,

    official_text TEXT NOT NULL,

    detection_hint_ja TEXT,

    before_example TEXT,
    after_example TEXT,

    extraction_method TEXT NOT NULL DEFAULT 'manual',
    review_status TEXT NOT NULL DEFAULT 'pending',

    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,

    FOREIGN KEY(product_id)
        REFERENCES kb_products(id),

    FOREIGN KEY(source_id)
        REFERENCES kb_sources(id)
);
```

---

# 16. change_type

製品共通の分類にする。

```text
breaking
deprecated
removed
behavior-change
default-change
configuration-change
dependency-change
compatibility-change
security-change
performance-change
new-feature
other
```

これなら、

```text
PHP API削除

.NET API Obsolete

PostgreSQL設定削除

EF Core Query挙動変更

Mroonga Normalizer変更
```

を同じ構造で表現できる。

---

# 17. impact

```text
critical
high
medium
low
none
unknown
```

公式にImpactがある場合は公式値を基に変換する。

---

# 18. 影響対象を汎用化する

以前の、

```text
change_symbols
change_configurations
```

などを、より一般化する。

`kb_change_targets`を作る。

```sql
CREATE TABLE kb_change_targets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    change_id INTEGER NOT NULL,

    target_type TEXT NOT NULL,

    identifier TEXT,

    action TEXT,

    details_json TEXT,

    FOREIGN KEY(change_id)
        REFERENCES kb_changes(id)
        ON DELETE CASCADE
);
```

---

# 19. target_type

```text
api
class
method
function
property
type
keyword

config
environment-variable

package
dependency

command
cli-option

file
directory

sql
database-object
schema
table
column
index

protocol
format

runtime-behavior
framework-behavior
database-behavior

platform
binary

other
```

これが今回の汎用化の重要部分である。

---

# 20. 具体例

PHPなら、

```text
target_type:
property

identifier:
dynamic property

action:
deprecated
```

.NETなら、

```text
target_type:
method

identifier:
SomeNamespace.OldApi()

action:
removed
```

PostgreSQLなら、

```text
target_type:
config

identifier:
old_parameter

action:
removed
```

EF Coreなら、

```text
target_type:
database-behavior

identifier:
LINQ translation

action:
changed
```

Mroongaなら、

```text
target_type:
keyword

identifier:
parser

action:
removed
```

となる。

---

# 21. action

```text
added
changed
deprecated
removed
renamed
default-changed
restricted
required
unsupported
other
```

---

# 22. 代替手段

## `kb_change_alternatives`

```sql
CREATE TABLE kb_change_alternatives (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    change_id INTEGER NOT NULL,

    alternative_type TEXT NOT NULL,

    replacement_product_id INTEGER,

    replacement_identifier TEXT,

    title TEXT NOT NULL,

    description TEXT,

    recommended INTEGER NOT NULL DEFAULT 0,

    source_url TEXT,

    FOREIGN KEY(change_id)
        REFERENCES kb_changes(id)
        ON DELETE CASCADE,

    FOREIGN KEY(replacement_product_id)
        REFERENCES kb_products(id)
);
```

---

# 23. alternative_type

```text
replace-api
replace-package
remove-usage
rewrite
configuration-change
upgrade-dependency
change-architecture
no-action
temporary-workaround
other
```

---

# 24. 例

```mermaid
flowchart TD

    Change["Package A 廃止"]

    Change --> A["Package Bへ移行"]
    Change --> B["機能自体を削除"]
    Change --> C["独自実装へ変更"]
    Change --> D["一時的に旧Version維持"]
```

どれを選ぶかは一般知識には保存しない。

Project Decisionで決める。

---

# 25. 互換性

製品同士の互換性も一般化する。

## `kb_compatibilities`

```sql
CREATE TABLE kb_compatibilities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    subject_version_id INTEGER NOT NULL,
    dependency_version_id INTEGER NOT NULL,

    relation_type TEXT NOT NULL,

    platform TEXT,
    architecture TEXT,

    status TEXT NOT NULL,

    notes TEXT,

    source_url TEXT,

    checked_at TEXT NOT NULL,

    FOREIGN KEY(subject_version_id)
        REFERENCES kb_product_versions(id),

    FOREIGN KEY(dependency_version_id)
        REFERENCES kb_product_versions(id)
);
```

---

# 26. compatibilityの例

```text
Mroonga 16.x
+
MariaDB 11.8
+
Windows x64
```

だけでなく、

```text
EF Core 10
+
.NET 10

Npgsql 9
+
PostgreSQL 17

PostGIS 3.x
+
PostgreSQL 16

Laravel 13
+
PHP 8.5
```

も同じテーブルで表現できる。

---

# 27. relation_type

```text
requires
supports
compatible-with
incompatible-with
bundled-with
tested-with
other
```

---

# 28. Knowledge側のER

```mermaid
erDiagram

    KB_PRODUCTS ||--o{ KB_PRODUCT_VERSIONS : has

    KB_PRODUCTS ||--o{ KB_SOURCES : documented_by

    KB_SOURCES ||--o{ KB_CHANGES : contains

    KB_PRODUCTS ||--o{ KB_CHANGES : changes

    KB_CHANGES ||--o{ KB_CHANGE_TARGETS : affects

    KB_CHANGES ||--o{ KB_CHANGE_ALTERNATIVES : has

    KB_PRODUCT_VERSIONS ||--o{ KB_COMPATIBILITIES : subject

    KB_PRODUCT_VERSIONS ||--o{ KB_COMPATIBILITIES : dependency
```

---

# 29. Project

Project側は、

**「実際に何を使っているか」**

を管理する。

---

# 30. `projects`

```sql
CREATE TABLE projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    name TEXT NOT NULL,

    root_path TEXT,

    description TEXT,

    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
```

PHPや.NETといったカラムは持たない。

以前の、

```text
php_target_version
laravel_target_version
mariadb_target_version
```

は廃止する。

汎用性がなくなるためである。

---

# 31. Project Component

## `project_components`

```sql
CREATE TABLE project_components (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,

    installed_version_id INTEGER,
    target_version_id INTEGER,

    source_type TEXT,

    is_direct INTEGER NOT NULL DEFAULT 1,
    is_development INTEGER NOT NULL DEFAULT 0,

    upgrade_status TEXT NOT NULL DEFAULT 'unknown',

    metadata_json TEXT,

    FOREIGN KEY(project_id)
        REFERENCES projects(id),

    FOREIGN KEY(product_id)
        REFERENCES kb_products(id),

    FOREIGN KEY(installed_version_id)
        REFERENCES kb_product_versions(id),

    FOREIGN KEY(target_version_id)
        REFERENCES kb_product_versions(id),

    UNIQUE(project_id, product_id)
);
```

---

# 32. 例

Laravelシステム：

```text
PHP             7.4   → 8.5
Laravel         6     → 13
MariaDB         10.4  → 11.8
Mroonga         xx    → yy
Guzzle          6     → 7
```

.NETシステム：

```text
.NET            8     → 10
ASP.NET Core    8     → 10
EF Core         8     → 10
PostgreSQL      16    → 18
Npgsql          8     → 10
Serilog         x     → y
```

どちらも`project_components`に保存できる。

---

# 33. Project Dependency

## `project_dependency_edges`

```sql
CREATE TABLE project_dependency_edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,

    from_component_id INTEGER NOT NULL,
    to_component_id INTEGER NOT NULL,

    dependency_type TEXT NOT NULL,

    constraint_text TEXT,

    FOREIGN KEY(project_id)
        REFERENCES projects(id),

    FOREIGN KEY(from_component_id)
        REFERENCES project_components(id),

    FOREIGN KEY(to_component_id)
        REFERENCES project_components(id)
);
```

---

# 34. Composer / NuGet / npmを同じ構造にする

```mermaid
flowchart TD

    Project

    Project --> Framework[ASP.NET Core]
    Project --> EF[EF Core]
    Project --> Npgsql[Npgsql]

    EF --> DotNet[.NET]
    Npgsql --> DotNet

    Npgsql --> PostgreSQL[PostgreSQL]
```

ComposerでもNuGetでもnpmでもDB構造は変えない。

Importerだけ変える。

---

# 35. Project Usage

実際にプロジェクトから使用している箇所。

## `project_usages`

```sql
CREATE TABLE project_usages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,

    component_id INTEGER,

    usage_type TEXT NOT NULL,

    identifier TEXT,

    file_path TEXT,

    line_start INTEGER,
    line_end INTEGER,

    excerpt TEXT,

    metadata_json TEXT,

    FOREIGN KEY(project_id)
        REFERENCES projects(id),

    FOREIGN KEY(component_id)
        REFERENCES project_components(id)
);
```

---

# 36. usage_type

```text
import
namespace
class
method
function
property

package-reference

configuration
environment-variable

sql
table
column
index

command
script

docker
ci

other
```

---

# 37. C#なら

例えば、

```csharp
using Npgsql;
```

を検出したら、

```text
usage_type:
namespace

identifier:
Npgsql
```

また、

```xml
<PackageReference Include="Npgsql" Version="8.0.0" />
```

なら、

```text
usage_type:
package-reference
```

として保存できる。

---

# 38. PostgreSQLなら

例えば、

```sql
CREATE EXTENSION pg_trgm;
```

なら、

```text
usage_type:
sql

identifier:
pg_trgm
```

とできる。

`postgresql.conf`の、

```text
some_parameter = ...
```

なら、

```text
usage_type:
configuration
```

となる。

---

# 39. Project Match

一般変更情報とプロジェクトの使用情報を関連付ける。

## `project_matches`

```sql
CREATE TABLE project_matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,

    change_id INTEGER NOT NULL,

    usage_id INTEGER,

    status TEXT NOT NULL DEFAULT 'detected',

    confidence REAL,

    reason TEXT,

    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,

    FOREIGN KEY(project_id)
        REFERENCES projects(id),

    FOREIGN KEY(change_id)
        REFERENCES kb_changes(id),

    FOREIGN KEY(usage_id)
        REFERENCES project_usages(id)
);
```

---

# 40. status

```text
detected
reviewed
applicable
not-applicable
resolved
verified
```

---

# 41. Project Decision

## `project_change_decisions`

```sql
CREATE TABLE project_change_decisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,

    change_id INTEGER NOT NULL,

    selected_alternative_id INTEGER,

    decision_type TEXT NOT NULL,

    reason TEXT,

    decided_at TEXT NOT NULL,

    FOREIGN KEY(project_id)
        REFERENCES projects(id),

    FOREIGN KEY(change_id)
        REFERENCES kb_changes(id),

    FOREIGN KEY(selected_alternative_id)
        REFERENCES kb_change_alternatives(id)
);
```

---

# 42. decision_type

```text
replace
remove
rewrite
replace-package
upgrade-package
configuration-change
architecture-change
keep-temporarily
already-not-used
not-applicable
no-change-required
```

---

# 43. 廃止への対応

これにより、

```mermaid
flowchart TD

    Deprecated["API Deprecated"]

    Deprecated --> A["新APIへ置換"]
    Deprecated --> B["機能を削除"]
    Deprecated --> C["Libraryごと削除"]
    Deprecated --> D["別Libraryへ移行"]
    Deprecated --> E["今回は旧API維持"]

    A --> Decision[Project Decision]
    B --> Decision
    C --> Decision
    D --> Decision
    E --> Decision
```

すべて表現できる。

---

# 44. Work Log

## `project_work_logs`

```sql
CREATE TABLE project_work_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,

    change_id INTEGER,
    decision_id INTEGER,

    work_type TEXT NOT NULL,

    target_path TEXT,

    summary TEXT NOT NULL,

    diff_reference TEXT,

    commit_hash TEXT,

    performed_at TEXT NOT NULL,

    FOREIGN KEY(project_id)
        REFERENCES projects(id)
);
```

---

# 45. work_type

```text
source-change
configuration-change
dependency-change
database-change
migration
file-removal
package-removal
package-replacement
infrastructure-change
documentation
other
```

---

# 46. Verification

テストをWork Logから分離する。

## `project_verifications`

```sql
CREATE TABLE project_verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,

    change_id INTEGER,
    work_log_id INTEGER,

    verification_type TEXT NOT NULL,

    command TEXT,

    result TEXT NOT NULL,

    output_summary TEXT,

    verified_at TEXT NOT NULL,

    FOREIGN KEY(project_id)
        REFERENCES projects(id),

    FOREIGN KEY(work_log_id)
        REFERENCES project_work_logs(id)
);
```

---

# 47. verification_type

```text
unit-test
integration-test
build
lint
static-analysis
database-check
manual-test
smoke-test
performance-test
search-regression-test
other
```

例えば、

```text
dotnet test

php artisan test

npm test

composer audit

dotnet build

EXPLAIN ANALYZE

全文検索Regression Test
```

などを同じテーブルに記録できる。

---

# 48. Project側ER

```mermaid
erDiagram

    PROJECTS ||--o{ PROJECT_COMPONENTS : uses

    PROJECTS ||--o{ PROJECT_DEPENDENCY_EDGES : has

    PROJECT_COMPONENTS ||--o{ PROJECT_USAGES : used_as

    PROJECTS ||--o{ PROJECT_MATCHES : detects

    KB_CHANGES ||--o{ PROJECT_MATCHES : applies_to

    KB_CHANGES ||--o{ PROJECT_CHANGE_DECISIONS : decided_for

    KB_CHANGE_ALTERNATIVES ||--o{ PROJECT_CHANGE_DECISIONS : selected

    PROJECT_CHANGE_DECISIONS ||--o{ PROJECT_WORK_LOGS : produces

    PROJECT_WORK_LOGS ||--o{ PROJECT_VERIFICATIONS : verified_by
```

---

# 49. Project Scan

現在状態を繰り返し読み込むため、Scanも持つ。

## `project_scans`

```sql
CREATE TABLE project_scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_id INTEGER NOT NULL,

    scan_type TEXT NOT NULL,

    source TEXT,

    status TEXT NOT NULL,

    scanned_at TEXT NOT NULL,

    FOREIGN KEY(project_id)
        REFERENCES projects(id)
);
```

---

# 50. Scan例

```text
composer.lock scan

NuGet PackageReference scan

package-lock.json scan

Dockerfile scan

php.ini scan

postgresql.conf scan

appsettings.json scan

Source Code scan

Database Schema scan
```

将来的に、

```text
前回Scanとの差分
```

も追跡できる。

---

# 51. ImporterをPlugin方式にする

製品を追加してもCoreを変更しない。

```ts
interface TechnologyImporter {

    supports(product: Product): boolean;

    discoverSources(
        context: ImportContext
    ): Promise<SourceCandidate[]>;

    fetch(
        source: SourceCandidate
    ): Promise<RawDocument>;

    parse(
        document: RawDocument
    ): Promise<ParsedDocument>;

    extractChanges(
        document: ParsedDocument
    ): Promise<ChangeCandidate[]>;
}
```

---

# 52. Importer一覧

```text
PhpImporter

LaravelImporter

DotNetImporter

AspNetCoreImporter

EfCoreImporter

PostgreSqlImporter

MariaDbImporter

MroongaImporter

ComposerImporter

NuGetImporter

NpmImporter
```

---

# 53. .NET系収集

例えば、

```text
.NET
├─ Breaking Changes
├─ Compatibility Notes
├─ Obsolete APIs
├─ Removed APIs
└─ Runtime Changes

ASP.NET Core
├─ Migration Guides
├─ Hosting Changes
├─ Authentication Changes
├─ Middleware Changes
└─ Configuration Changes

EF Core
├─ Breaking Changes
├─ Query Behavior
├─ Migration Changes
├─ Provider Changes
└─ Database Compatibility

NuGet Package
├─ Package Metadata
├─ CHANGELOG
├─ Migration Guide
├─ GitHub Releases
└─ Dependency Requirements
```

として収集する。

---

# 54. PostgreSQL系収集

```text
PostgreSQL
├─ Major Release Notes
├─ Migration Notes
├─ Incompatible Changes
├─ SQL Behavior
├─ Configuration
├─ Removed Parameters
├─ Changed Defaults
├─ Extension Compatibility
├─ Index / Collation
└─ pg_upgrade関連情報
```

さらに、

```text
PostGIS
pgvector
pg_trgm
Npgsql
```

などは別Productとして扱う。

---

# 55. Package Manager Scan

Package ManagerごとにScannerを用意する。

```text
ComposerScanner
    composer.json
    composer.lock

NuGetScanner
    *.csproj
    packages.lock.json

NpmScanner
    package.json
    package-lock.json

PythonScanner
    pyproject.toml
    uv.lock
```

DB構造は共通。

---

# 56. Scan構造

```mermaid
flowchart LR

    Project[Project]

    Project --> Detect[Technology Detection]

    Detect --> Composer[Composer Scanner]
    Detect --> NuGet[NuGet Scanner]
    Detect --> Npm[npm Scanner]
    Detect --> Db[Database Scanner]
    Detect --> Config[Configuration Scanner]

    Composer --> Components[project_components]
    NuGet --> Components
    Npm --> Components
    Db --> Components

    Components --> Dependencies[project_dependency_edges]

    Config --> Usage[project_usages]
```

---

# 57. FTS5

検索IndexにはKnowledgeのみを基本的に登録する。

対象：

```text
title

summary_ja

official_text

detection_hint_ja

change target identifiers

alternative descriptions
```

FTSテーブルは正本ではない。

---

# 58. Embedding

Ruri v3 30mを初期モデルとする。

Embedding対象は主に、

```text
kb_changes
```

である。

Project固有Work Logは、初期段階ではVector化しない。

---

# 59. Embedding Text

例えば.NETなら、

```text
製品:
ASP.NET Core

Version:
8 → 9

変更:
認証Middlewareの○○動作が変更された。

影響:
旧設定を使用するAuthentication構成。

調査方法:
Program.csとAddAuthentication周辺を確認する。

関連:
AddAuthentication
UseAuthentication

代替:
新しい設定方法へ変更。
```

のような検索用日本語文書を生成する。

---

# 60. Vector Index

```text
kb_changes
      ↓
EmbeddingTextBuilder
      ↓
Ruri v3 30m
      ↓
sqlite-vec
```

Vectorは再生成可能。

---

# 61. Hybrid Search

```mermaid
flowchart TD

    Q[Query]

    Q --> Exact[Exact Target Match]
    Q --> FTS[FTS5]
    Q --> Embedding[Ruri]

    Embedding --> Vector[sqlite-vec]

    Exact --> Rank[Hybrid Ranker]
    FTS --> Rank
    Vector --> Rank

    Rank --> Result[Results]
```

---

# 62. Exact Matchを最優先

例えば、

```text
UseAuthentication

NpgsqlConnection

TokenBigram

innodb_buffer_pool_instances

dynamic property
```

などはVectorより完全一致検索を優先する。

---

# 63. Vectorが有効な例

```text
認証周りで動かなくなりそうな変更

LINQの結果が変わる可能性がある変更

PostgreSQLの検索結果が変わる変更

古いAPIを使っていて将来削除されるもの
```

など。

---

# 64. Project分析

最終的な分析フロー：

```mermaid
flowchart TD

    Components[Project Components]

    KB[Knowledge Base]

    Components --> Candidate[Version範囲から候補抽出]
    KB --> Candidate

    Candidate --> Target[Change Targets取得]

    Target --> Usage[Project Usage検索]

    Usage --> Match[Project Match]

    Match --> Decision[Decision]

    Decision --> Work[Work]

    Work --> Verification[Verification]
```

---

# 65. MCP

MCPはDB操作APIにしない。

ユースケース単位とする。

---

# 66. Knowledge MCP Tools

```text
search_changes

get_change

get_change_targets

get_change_alternatives

list_changes_between_versions

check_compatibility

search_deprecations

search_removed_features
```

---

# 67. Project MCP Tools

```text
get_project_components

get_upgrade_candidates

record_usage

record_match

record_decision

record_work

record_verification

get_pending_changes

get_upgrade_status
```

---

# 68. Report MCP

```text
generate_upgrade_report

generate_pending_report

generate_breaking_change_report

generate_verification_report
```

---

# 69. Copilot利用イメージ

例えばC#プロジェクトなら、

```text
.NET 8から10
ASP.NET Core 8から10
EF Core 8から10
PostgreSQL 16から18

へアップグレードしたい。

このRepositoryに該当する
Breaking Changeを調査して。
```

Copilot：

```mermaid
sequenceDiagram

    participant C as Copilot
    participant M as MCP
    participant KB as Knowledge DB
    participant Repo as Repository

    C->>M: get_upgrade_candidates
    M->>KB: Version範囲検索

    KB-->>M: Changes
    M-->>C: Candidate Changes

    C->>Repo: Target/API/Config検索
    Repo-->>C: Usage

    C->>M: record_match

    C->>M: get_change_alternatives

    C->>M: record_decision

    C->>Repo: Modify

    C->>Repo: Build/Test

    C->>M: record_work
    C->>M: record_verification
```

---

# 70. 作業報告

一般知識とProject情報をJOINする。

```mermaid
flowchart LR

    Change[kb_changes]
    Target[kb_change_targets]
    Match[project_matches]
    Decision[project_change_decisions]
    Work[project_work_logs]
    Verification[project_verifications]

    Change --> Report[Report Service]
    Target --> Report
    Match --> Report
    Decision --> Report
    Work --> Report
    Verification --> Report

    Report --> Markdown[Markdown Report]
```

---

# 71. 報告書例

```markdown
## ASP.NET Core 9 対応

### Authentication設定変更

#### 根拠
ASP.NET Core公式Breaking Changes

#### 該当箇所
Program.cs

#### 対応方針
新しいAuthentication設定方法へ移行。

#### 実施内容
旧設定を削除し、新しいAPIへ変更。

#### 検証
dotnet build
dotnet test

#### 結果
PASS
```

---

# 72. 廃止Packageの場合

```markdown
## Foo.Package 廃止対応

### 状況

Foo.Packageは対象.NET Versionではサポートされない。

### 対応候補

- Bar.Packageへ移行
- 該当機能を削除
- 独自実装

### 採用

Bar.Packageへ移行。

### 理由

対象.NET Versionに正式対応しており、
既存用途を置き換え可能なため。

### 作業

Foo.Packageを削除。
Bar.Packageを追加。
関連コードを変更。

### 検証

dotnet test

PASS
```

---

# 73. DBの境界

最終的な構造は、

```mermaid
flowchart TB

    subgraph GENERAL["GENERAL KNOWLEDGE"]
        Product
        Version
        Source
        Change
        ChangeTarget
        Alternative
        Compatibility
    end

    subgraph PROJECT["PROJECT STATE"]
        Project
        Component
        Dependency
        Usage
        Match
        Decision
        Work
        Verification
    end

    subgraph DERIVED["DERIVED"]
        FTS
        Embedding
        Vector
    end

    GENERAL --> PROJECT

    GENERAL --> DERIVED
```

とする。

---

# 74. Migration構成

```text
001_schema_migrations.sql

010_kb_products.sql
011_kb_product_versions.sql
012_kb_sources.sql
013_kb_changes.sql
014_kb_change_targets.sql
015_kb_change_alternatives.sql
016_kb_compatibilities.sql

020_projects.sql
021_project_scans.sql
022_project_components.sql
023_project_dependency_edges.sql
024_project_usages.sql
025_project_matches.sql
026_project_change_decisions.sql
027_project_work_logs.sql
028_project_verifications.sql

030_idx_fts.sql
031_idx_embedding_models.sql
032_idx_embedding_units.sql
033_idx_vectors.sql
```

---

# 75. ディレクトリ構成

```text
technology-upgrade-kb/
│
├─ apps/
│  ├─ cli/
│  ├─ api/
│  ├─ web/
│  └─ mcp/
│
├─ packages/
│  │
│  ├─ core/
│  │  ├─ knowledge/
│  │  ├─ project/
│  │  ├─ search/
│  │  ├─ analysis/
│  │  └─ report/
│  │
│  ├─ db/
│  │
│  ├─ embedding/
│  │
│  ├─ importers/
│  │  ├─ php/
│  │  ├─ laravel/
│  │  ├─ dotnet/
│  │  ├─ aspnetcore/
│  │  ├─ efcore/
│  │  ├─ postgresql/
│  │  ├─ mariadb/
│  │  └─ mroonga/
│  │
│  └─ scanners/
│     ├─ composer/
│     ├─ nuget/
│     ├─ npm/
│     ├─ source/
│     ├─ database/
│     └─ configuration/
│
├─ data/
│  └─ upgrade.sqlite
│
└─ docs/
   └─ design.md
```

---

# 76. 実装順序

```mermaid
flowchart TD

    A[SQLite / Migration]

    B[Generic Knowledge Model]

    C[Generic Project Model]

    D[CLI CRUD]

    E[FTS5]

    F[Technology Importer Interface]

    G[Project Scanner Interface]

    H[PHP / Laravel Importer]

    I[Composer Scanner]

    J[Ruri / sqlite-vec]

    K[Hybrid Search]

    L[Web UI]

    M[MCP]

    N[Project Analysis]

    O[Report]

    P[.NET / NuGet]

    Q[PostgreSQL]

    A --> B --> C --> D --> E --> F --> G

    G --> H --> I --> J --> K --> L --> M --> N --> O

    O --> P
    P --> Q
```

---

# 77. 最初の完成地点

最初から全技術を実装しない。

Coreを汎用設計にした上で、

```text
PHP
Laravel
Composer
```

を最初の実証対象にする。

この時点で、

```text
kb_products
kb_product_versions
kb_sources
kb_changes
kb_change_targets
kb_change_alternatives

projects
project_components
project_usages
project_matches
project_change_decisions
```

が製品固有コードなしで動いていればよい。

その後、

```text
.NET
ASP.NET Core
EF Core
NuGet
PostgreSQL
Npgsql
```

を追加して、DB Migrationなしで対応できることを確認する。

---

# 78. 設計上の完成形

このシステムは、

```text
「LaravelのアップグレードDB」
```

ではなく、

```text
Technology Upgrade Knowledge Base
```

とする。

Coreが知る概念は、

```text
Product
Version
Source
Change
Target
Alternative
Compatibility

Project
Component
Usage
Match
Decision
Work
Verification
```

だけ。

Coreは、

```text
PHPとは何か

Laravelとは何か

.NETとは何か

PostgreSQLとは何か
```

を知らない。

製品固有知識はImporter / Scannerへ閉じ込める。

---

# 79. 最重要設計原則

```mermaid
flowchart LR

    Product["Technology"]

    Product --> Version

    Version --> Change

    Change --> Target

    Change --> Alternative

    Change --> Compatibility

    Target --> Match

    Match --> Decision

    Alternative --> Decision

    Decision --> Work

    Work --> Verification
```

これを技術スタック共通の基本モデルとする。

これにより、

**PHP/Laravel/MariaDB/Mroongaから開始しても、将来的にC#/.NET/ASP.NET Core/EF Core/PostgreSQL/NuGetなどを、同じSQLite・同じFTS・同じVector検索・同じMCP・同じ作業報告の仕組みに載せられる構成とする。**