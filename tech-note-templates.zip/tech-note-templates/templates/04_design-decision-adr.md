---
title: ""
type: design-decision
adr_number:
status: proposed # proposed | accepted | rejected | superseded | deprecated
decision_date: YYYY-MM-DD
tags: []
created: YYYY-MM-DD
updated: YYYY-MM-DD
related: []
summary: ""
---

# ADR-{{adr_number}}: {{title}}

## 1. 状態

<!--
proposed / accepted / rejected / superseded / deprecated
-->

## 2. 背景

<!--
なぜこの設計判断が必要になったのか。
業務上・技術上の制約も書く。
-->

## 3. 課題

<!--
何を決めないといけないのか。
-->

## 4. 決定

<!--
採用する方針を短く明確に書く。
-->

## 5. 採用理由

- 
- 
- 

## 6. 選択肢

### 案A: 

メリット:

- 

デメリット:

- 

### 案B: 

メリット:

- 

デメリット:

- 

### 案C: 

メリット:

- 

デメリット:

- 

## 7. 比較表

| 観点 | 案A | 案B | 案C |
|---|---|---|---|
| 実装コスト |  |  |  |
| 運用コスト |  |  |  |
| セキュリティ |  |  |  |
| 拡張性 |  |  |  |
| 既存影響 |  |  |  |
| AI/Copilot作業適性 |  |  |  |

## 8. 影響範囲

| 種別 | 影響 |
|---|---|
| DB |  |
| API |  |
| フロント |  |
| バッチ/Job |  |
| 権限 |  |
| テスト |  |
| 運用 |  |

## 9. リスク

| リスク | 影響 | 対策 |
|---|---|---|
|  |  |  |

## 10. 未解決事項

- [ ] 
- [ ] 

## 11. 将来見直す条件

<!--
どんな条件になったらこの判断を見直すか。
-->

- 
- 

## 12. 関連ノート

- [[関連ノート名]]
