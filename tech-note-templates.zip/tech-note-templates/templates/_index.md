---
title: 技術ノートテンプレート索引
type: index
tags:
  - templates
  - tech-note
created: YYYY-MM-DD
updated: YYYY-MM-DD
---

# 技術ノートテンプレート索引

## テンプレート

- [[00_basic-tech-note]]: 汎用の技術ノート
- [[01_research-note]]: 技術調査・用語整理
- [[02_howto]]: 手順書・セットアップ
- [[03_troubleshooting]]: 障害調査・ハマりどころ
- [[04_design-decision-adr]]: 設計判断・ADR
- [[05_comparison]]: 技術比較・候補比較
- [[06_implementation-log]]: 実装ログ・作業記録
- [[07_specs-reading]]: 既存仕様・コード理解
- [[08_ai-copilot-instruction]]: AI/Copilot 指示書
- [[09_knowledge-share]]: 社内共有・教育用ナレッジ

## 優先して使うテンプレート

1. [[04_design-decision-adr]]
2. [[03_troubleshooting]]
3. [[08_ai-copilot-instruction]]
4. [[02_howto]]
5. [[01_research-note]]
