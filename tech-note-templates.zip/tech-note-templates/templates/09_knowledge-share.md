---
title: ""
type: knowledge-share
status: draft # draft | reviewed | published | archived
audience: internal # internal | beginner | engineer | management
tags: []
created: YYYY-MM-DD
updated: YYYY-MM-DD
related: []
summary: ""
---

# {{title}}

## 1. 伝えたいこと

<!--
このノートで一番伝えたい結論。
-->

## 2. なぜ重要か

<!--
業務上の事故防止、品質維持、効率化、教育上の理由など。
-->

## 3. 対象者

- 
- 
- 

## 4. 前提知識

<!--
読む人に必要な前提。
専門用語を減らす。
-->

## 5. 具体例

### よい例

```txt
# よい例
```

理由:

- 

### 悪い例

```txt
# 悪い例
```

問題点:

- 

## 6. やってよいこと

- 
- 
- 

## 7. やってはいけないこと

- 
- 
- 

## 8. 判断に迷うケース

| ケース | 判断 | 理由 | 相談先 |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |

## 9. チェックリスト

- [ ] 
- [ ] 
- [ ] 

## 10. 関連ルール・資料

- [[関連ノート名]]
- 

## 11. 更新履歴

| 日付 | 変更内容 | 更新者 |
|---|---|---|
| YYYY-MM-DD | 初版 |  |
