# 技術ノート Markdown テンプレート集

Obsidian や Markdown ベースの技術メモで使うためのテンプレート集です。

## ファイル一覧

| ファイル | 用途 |
|---|---|
| `00_basic-tech-note.md` | 汎用の技術ノート |
| `01_research-note.md` | 技術調査・用語整理 |
| `02_howto.md` | 手順書・セットアップ |
| `03_troubleshooting.md` | 障害調査・ハマりどころ |
| `04_design-decision-adr.md` | 設計判断・ADR |
| `05_comparison.md` | 技術比較・候補比較 |
| `06_implementation-log.md` | 実装ログ・作業記録 |
| `07_specs-reading.md` | 既存仕様・コード理解 |
| `08_ai-copilot-instruction.md` | AI/Copilot 指示書 |
| `09_knowledge-share.md` | 社内共有・教育用ナレッジ |

## 使い方

1. 必要なテンプレートをコピーする
2. `title`, `tags`, `created`, `updated` を埋める
3. 不要な章は削除する
4. 関連ノートは `[[ノート名]]` でリンクする

## おすすめ運用

最初は以下の5種類だけでも十分です。

1. `04_design-decision-adr.md`
2. `03_troubleshooting.md`
3. `08_ai-copilot-instruction.md`
4. `02_howto.md`
5. `01_research-note.md`

## フォルダ例

```txt
notes/
  tech/
    research/
    howto/
    troubleshooting/
    design/
    comparison/
    implementation/
    specs-reading/
    ai-prompts/
    knowledge-share/
```

## front matter の主な項目

| 項目 | 意味 |
|---|---|
| `title` | ノートタイトル |
| `type` | ノート種別 |
| `status` | 状態 |
| `tags` | 検索用タグ |
| `created` | 作成日 |
| `updated` | 更新日 |
| `related` | 関連ノート |
| `summary` | 1〜3行の要約 |

## status の例

| status | 意味 |
|---|---|
| `draft` | 下書き |
| `active` | 現在利用中 |
| `verified` | 手順確認済み |
| `resolved` | 解決済み |
| `accepted` | 採用済み |
| `archived` | 保管・古い情報 |
| `outdated` | 情報が古い |
